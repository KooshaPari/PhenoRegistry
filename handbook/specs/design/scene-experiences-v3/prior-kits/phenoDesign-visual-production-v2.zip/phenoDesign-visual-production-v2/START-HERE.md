# phenoDesign · Visual production v2

This expands the frontend/3D kit into a cross-media authoring, delivery and verification package. It is a **local integration overlay and agent handoff**, not a remotely committed implementation. Start with `AGENT-HANDOFF.md`; browse `index.html` for tools and skills.

## Contents

- `skills/`: 26 new workflows spanning raster, vector, typography, characters, animation, motion/video, generative media, native hosts, spatial work and E2E verification.
- `reference/frontend-3d-agent-kit/`: the complete original kit, including its 18 original skills, one upstream Anthropic skill, procedural trainer asset and web demos. Its evidence is historical and does not qualify this extension.
- `phenoDesign-overlay/`: a new private integration-primitives package and guarded replacements for PR87's Remotion staging, source geometry and timing components.
- `worker-recipes/`: native Illustrator, Photoshop and After Effects authoring canaries, plus Rive instructions. These are worker-side recipes, not a second engine under phenoDesign/engine.
- `scripts/`: environment probe, guarded overlay installer, Illustrator data compiler, media checks and skill activation.
- `examples/`: vector interaction canary, data jobs and source/acceptance examples.
- `resources/`: annotated source catalog and upstream skill acquisition references.
- `docs/`: ownership, actual repository audit, complete workflow and implementation backlog.
- `evidence/`: actual checks and explicitly labeled environment limitations from package preparation.

## Run locally

```sh
python scripts/probe_tools.py
node --test phenoDesign-overlay/packages/visual-production/test/*.test.mjs
python -m unittest discover -s tests -p 'test_*.py'
python scripts/apply_overlay.py --repo /path/to/PhenoDesign
```

Read the dry-run output. Reconcile PR87 and any changed heads first; the installer refuses to pretend absent migration files exist. Apply only on the intended owned worktree:

```sh
python scripts/apply_overlay.py --repo /path/to/PhenoDesign --apply
python scripts/activate_skills.py --repo /path/to/PhenoDesign --harness codex
```

Skill activation is another dry-run by default; add `--apply` after review. Forge uses `--harness forge`. Existing harness policy files are never replaced. Keep this extracted kit in a stable directory: inherited skills receive its actual absolute reference-kit path, so their original scripts and resources remain resolvable. Native recipes are not silently copied into a second render engine. After integration, align Remotion dependency versions and regenerate the actual Bun lockfile on device; no guessed lockfile is included.

## Boundaries

“Workflow coverage” does not mean every application, plugin and target has passed on-device E2E. Read `evidence/VALIDATION.md`. Native Adobe, Blender, Rive and complete Remotion rendering were not executed in this environment. The included technical shapes are canaries, not finished identity or character art. No Adobe binaries, proprietary fonts, purchased assets or credentials are included.
