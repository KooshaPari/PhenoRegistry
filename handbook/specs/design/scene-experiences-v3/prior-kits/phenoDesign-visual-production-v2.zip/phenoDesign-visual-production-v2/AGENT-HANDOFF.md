# Execute the phenoDesign visual-production expansion

The required scope is **all major visual forms**: frontend layout/type, vector illustration, raster/compositing, icons/identity, characters, frame animation, rigged interactive 2D, 2.5D, 3D objects/scenes/materials, procedural graphics, video/audio/captions, diagrams/data stories, editorial/print and spatial delivery. The product must support creation, iteration, export, actual consumption and E2E validation—not only screenshots or a renderer catalog.

## Intent and authority

PhenoDesign is the coherent design-facing entry point. Reuse its accepted tokens/themes and the partially absorbed journey viewer/recorder/Remotion packages. Complete the user-requested breadth without building a second registry, graphics SDK or scheduler. Where asset-engine currently owns headless execution, expose it through phenoDesign or intentionally migrate ownership with source custody and consumer updates; do not maintain parallel owners. The user's current desired breadth supersedes a stale “tokens only” interpretation.

## Start from actual code, not this snapshot

Inspect current heads and working changes. The inspected snapshot was main `d11733b1525cb97e045dc7f8d67a05df5501f6c1`; PR87 head `6c99a15337505b55f46a9f576465db5e4053b416` on `absorb-phenojourneys-vue`. At inspection the PR was open/unmerged. Read the current migration and exact source before applying the supplied guarded overlay. Retain newer valid fixes.

1. Run `scripts/probe_tools.py`, inspect `docs/REPOSITORY-AUDIT.md`, and run overlay dry-run. Resolve missing migration prerequisites rather than recreating packages. Apply reviewed changes in an owned worktree. Preserve tokens/theme/public exports, tests and unrelated work.
2. Run the dependency-free regression suite, then actual workspace typechecks and target tests. Add Remotion to the workspace and align dependencies/lockfile using the locally installed toolchain. Test real SSR rendering; a `.mjs` syntax check is not that test.
3. Qualify the user's installed Illustrator and Photoshop on dedicated native hosts. Start from `worker-recipes/`. Run the create → editable save → close → cold reopen → structural inspection → export → independent pixel inspection journey. Resolve the script/plugin version, file-grant and session adapter gaps. Automate through the existing journey/native worker machinery; no foreground focus theft.
4. Prove one complete vector/raster/3D/motion product story in an actual consuming page. The story must contain real authored sources and useful interaction; it must not be a dashboard of placeholder shapes. The included dial/trainer are plumbing canaries only. Build and critique the final visual quality for the real subject.
5. Expand by capability demand. Use relevant skills, qualify/acquire missing tools through official sources, retain rights/provenance and complete the same E2E loop for each enabled adapter. Rive CLI, Lottie, Remotion, AE, Krita or Blender are choices, not mandatory installations.

## Required fixes and acceptance

Prioritize the backlog in `docs/BACKLOG.json`. Complete remaining recorder/viewer schema and path compatibility, capture-failure handling, native cold-start tests, Remotion source-dimension/crop/audio tests and actual consumer fallback checks. Add intentional negative cases. Do not “resolve” them by removing checks, labeling fallback HTML as ARIA, or allowing an empty evidence set to pass.

For each enabled capability return the exact source files, recipe/version, output hashes, native/runtime identity, exercised journey and verdict. Keep PASS, FAIL, BLOCKED_ENV, BLOCKED_AUTH, INCONCLUSIVE and CANCELLED distinct. Render receipts are not independent verification. Retain immutable raw evidence and separately named presentation derivatives. A model's aesthetic score never overwrites hard failed assertions.

## Continue through implementation

Proceed depth-first on ready authorized work. Do not stop after installing skills, writing another plan, making an MP4 or obtaining a green schema test. Open the actual outputs, assess them at their placement size, repair defects, exercise the real consumer and retain failures. Report precise host/auth/rights blockers without claiming unavailable paths succeeded. No purchases, private uploads, merges, public publication or unrelated system changes are implied by this handoff.
