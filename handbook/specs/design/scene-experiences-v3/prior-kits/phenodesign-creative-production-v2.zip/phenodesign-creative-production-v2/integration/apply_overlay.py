#!/usr/bin/env python3
"""Preflight-first, guarded local PhenoDesign integration. No Git/network actions."""
from __future__ import annotations
import argparse, hashlib, json, os, tempfile
from pathlib import Path, PurePosixPath
from dataclasses import dataclass
PACK=Path(__file__).resolve().parents[1]

class Conflict(RuntimeError):pass

def blob_sha(data:bytes)->str:
    return hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()

def safe_relative(value:str)->Path:
    if not isinstance(value,str) or not value or "\\" in value or "\0" in value:
        raise Conflict('invalid relative path')
    p=PurePosixPath(value)
    if p.is_absolute() or any(x in ('..','.') for x in value.split('/')) or ':' in value or str(p)!=value:
        raise Conflict(f'unsafe path: {value}')
    return Path(*p.parts)

def no_symlinks(root:Path,relative:Path):
    p=root
    for part in relative.parts:
        p=p/part
        if p.is_symlink():raise Conflict(f'symlink path is not an integration target: {p}')
        if p.exists() and p!=root/relative and not p.is_dir():raise Conflict(f'parent is not a directory: {p}')

@dataclass
class Change:
    path:Path
    data:bytes
    previous:bytes|None
    action:str

def plan(repo:Path,pack:Path,manifest:dict)->list[Change]:
    repo=repo.resolve();pack=pack.resolve()
    try:
        no_symlinks(repo,Path('package.json'))
        package=json.loads((repo/'package.json').read_text(encoding='utf-8'))
    except (OSError,ValueError) as e:raise Conflict(f'cannot read target package.json: {e}') from e
    if package.get('name')!='@phenotype/design':raise Conflict('target is not the expected @phenotype/design repository')
    changes=[];seen=set()
    for row in manifest['files']:
        src_rel=safe_relative(row['source']);dst_rel=safe_relative(row['target'])
        if str(dst_rel) in seen:raise Conflict('duplicate destination')
        seen.add(str(dst_rel));no_symlinks(pack,src_rel);no_symlinks(repo,dst_rel)
        source=pack/src_rel;dest=repo/dst_rel
        if not source.is_file() or source.stat().st_size>32*1024*1024:raise Conflict(f'bad source: {source}')
        data=source.read_bytes()
        if hashlib.sha256(data).hexdigest()!=row['sha256']:raise Conflict(f'source checksum changed: {source}')
        if dest.exists() and not dest.is_file():raise Conflict(f'destination not a file: {dest}')
        previous=dest.read_bytes() if dest.exists() else None
        if previous==data:action='UNCHANGED'
        elif row.get('expected_git_blob'):
            if previous is None or blob_sha(previous)!=row['expected_git_blob']:
                raise Conflict(f'expected source revision mismatch: {dst_rel}; refresh migration/inspect changes, do not overwrite')
            action='REPLACE_VERIFIED_BASE'
        elif previous is not None:raise Conflict(f'existing different destination: {dst_rel}')
        else:action='ADD'
        changes.append(Change(dest,data,previous,action))
    return changes

def atomic_write(path:Path,data:bytes):
    fd,name=tempfile.mkstemp(prefix='.pd-overlay-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
        os.replace(name,path)
    finally:
        if os.path.exists(name):os.unlink(name)

def apply(repo:Path,pack:Path,manifest:dict)->list[Change]:
    repo=repo.resolve();lock=repo/'.phenodesign-creative-overlay.lock';owned=False
    applied=[];created_dirs=[]
    try:
        fd=os.open(lock,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600);owned=True
        with os.fdopen(fd,'w') as f:f.write(str(os.getpid()))
        changes=plan(repo,pack,manifest)
        for c in changes:
            if c.action=='UNCHANGED':continue
            no_symlinks(repo,c.path.relative_to(repo))
            current=c.path.read_bytes() if c.path.exists() else None
            if current!=c.previous:raise Conflict(f'destination changed during integration: {c.path}')
            missing=[];parent=c.path.parent
            while not parent.exists():missing.append(parent);parent=parent.parent
            for parent in reversed(missing):parent.mkdir();created_dirs.append(parent)
            atomic_write(c.path,c.data);applied.append(c)
        return changes
    except Exception:
        # Never overwrite a concurrent writer during rollback. Require an external
        # repository write lease as well; this lock coordinates this installer only.
        for c in reversed(applied):
            if c.path.is_symlink() or not c.path.exists() or c.path.read_bytes()!=c.data:continue
            if c.previous is None:c.path.unlink()
            else:atomic_write(c.path,c.previous)
        for parent in reversed(created_dirs):
            try:parent.rmdir()
            except OSError:pass
        raise
    finally:
        if owned:lock.unlink(missing_ok=True)

def main():
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--repo',required=True,type=Path);ap.add_argument('--apply',action='store_true')
    a=ap.parse_args();m=json.loads((PACK/'integration/manifest.json').read_text())
    try:
        changes=apply(a.repo,PACK,m) if a.apply else plan(a.repo,PACK,m)
    except (OSError,ValueError,Conflict) as e:raise SystemExit(f'BLOCKED: {e}')
    print(json.dumps({'mode':'APPLIED' if a.apply else 'DRY_RUN','repo':str(a.repo.resolve()),'changes':[{'path':str(c.path.relative_to(a.repo.resolve())),'action':c.action} for c in changes]},indent=2))
if __name__=='__main__':main()
