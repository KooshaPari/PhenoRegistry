# Apply into the existing PhenoDesign repo, not a new system

`apply_overlay.py` defaults to a read-only preflight. It requires the target
package name `@phenotype/design`, rejects symlinks/path escapes/conflicting files,
checks every source SHA-256, and replaces the imported renderer **only** when its
Git blob matches the inspected version. All checks complete before writes.

```sh
python integration/apply_overlay.py --repo /your/PhenoDesign
python integration/apply_overlay.py --repo /your/PhenoDesign --apply
```

Acquire the existing repo write lease first. The installer lock only coordinates
other copies of this installer. It cannot stop an unrelated editor or agent.
Writes are per-file atomic, with rollback of owned changes on an exception.
Unrelated concurrent changes are preserved, not silently overwritten.

## What changes

- Replace `remotion/doc-embeds/bin/render.mjs` against the exact inspected blob.
- Add its pure validation/staging, fit-transform and process helpers.
- Add regression tests **in the actual Remotion package**, not only this kit.
- Add `creative-production/` skills, native adapters, documentation, original
  examples, contracts and the preserved v1 source/resource kit. No new service,
  registry, package publication or authority over the existing Journey schema.

## What is deliberately not automatic

No PR merge, Git commit/push, remote changes, dependency installation, licenses,
application permissions, existing brand/token updates, AGENTS.md replacement or
CI success claim. `main` without the inspected renderer is expected to fail
preflight. Refresh PR #87 and reconcile newer edits rather than bypassing this.

The fit/crop helper is unit-tested but the imported React composition still
needs the changes in `docs/COMPOSITION-WIRING.md` and actual Remotion frame tests.
The renderer improvement does not itself complete that visual integration.

After local integration run:

```sh
node --test remotion/doc-embeds/tests/creative-*.test.mjs
python creative-production/scripts/build_vector_canary.py --out /new/canary
python creative-production/scripts/browser_canary.py --transport http --out /new/browser
```

Then qualify native apps, actual Remotion/browser rendering, and the real VitePress
consumer. Unit tests and the preparation environment's inline consumer are not
proof of those paths. `manifest.json` records exact source-to-target mappings.
