# PhenoDesign creative production recipes

This directory is part of PhenoDesign, not a new product or independent registry.
Use `docs/CAPABILITY-MAP.md`, `docs/PIPELINE-AND-E2E.md`, the medium-specific skills,
and the canonical token/manifest/verifier owners already present in this repo.
The original handoff snapshot is historical; refresh the actual migration state.

Start with `scripts/build_vector_canary.py` and `scripts/browser_canary.py`.
Native Adobe adapters require a qualified local app/session. Remotion source in
`examples/remotion/` is an integration specimen, not evidence of a render.

The installed Remotion regression tests live in:
`../remotion/doc-embeds/tests/creative-*.test.mjs`.
Run those from the repository root to test the actual installed helpers.
Geometry composition wiring remains in `docs/COMPOSITION-WIRING.md`.

The v1 source/resource kit is retained under `frontend-3d-v1/`; its old evidence
is inherited, not a new test result. The ZIP's preparation evidence is not copied
here as proof of this repo. Produce fresh evidence through current consumers.
