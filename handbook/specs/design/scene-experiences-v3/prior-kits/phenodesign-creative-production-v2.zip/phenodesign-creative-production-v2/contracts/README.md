# Optional creative metadata extension

This is a proposed extension payload, **not** a replacement Journey, BundleManifest,
asset registry, approval authority or signature format. Bind it to an existing
manifest only after reconciling actual versions. Rights status and verification
fields are claims that require evidence, not automatic approvals. Relative paths
in the example resolve from this pack root. The consumer check was an inline
SVG/DOM fixture test, not a deployed-site or native-Adobe roundtrip test.

The schema validates shape. It does not validate file bytes, license ownership,
consumer behavior, renderer output, signature authenticity or visual quality.
Keep evidence references and existing trusted verifier boundaries intact.
