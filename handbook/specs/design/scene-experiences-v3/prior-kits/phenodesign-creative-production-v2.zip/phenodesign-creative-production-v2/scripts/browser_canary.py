#!/usr/bin/env python3
"""Exercise the actual SVG consumer. Inline mode tests rendering, not HTTP deployment."""
from __future__ import annotations
import argparse, io, json, shutil, threading
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from functools import partial
from pathlib import Path
from PIL import Image, ImageChops
from playwright.sync_api import sync_playwright
ROOT=Path(__file__).resolve().parents[1]

def changed(a:bytes,b:bytes)->bool:
    return ImageChops.difference(Image.open(io.BytesIO(a)).convert('RGB'),Image.open(io.BytesIO(b)).convert('RGB')).getbbox() is not None

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--out',type=Path,required=True)
    ap.add_argument('--transport',choices=['http','inline'],default='http',help='inline loads the exact self-contained fixture with set_content; not deployed HTTP evidence')
    args=ap.parse_args();out=args.out.resolve()
    if out.exists() and any(out.iterdir()):raise SystemExit('refusing non-empty output directory')
    out.mkdir(parents=True,exist_ok=True);checks=[];errors=[];server=None;thread=None;browser=None
    result={'status':'NOT_RUN','checks':checks,'transport':args.transport,'renderer':'svg-dom','hardwareGPUVerified':False,'nativeAdobeVerified':False,'RemotionVerified':False,'deployedConsumerVerified':False,'errors':errors}
    def check(name,condition):
        checks.append({'name':name,'pass':bool(condition)})
        if not condition:raise AssertionError(name)
    try:
        fixture=(ROOT/'examples/interactive-vector/index.html').read_text(encoding='utf-8')
        if args.transport=='http':
            server=ThreadingHTTPServer(('127.0.0.1',0),partial(SimpleHTTPRequestHandler,directory=str(ROOT/'examples/interactive-vector')))
            thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
            url=f'http://127.0.0.1:{server.server_port}/index.html'
        def load(page):
            if args.transport=='http':page.goto(url,wait_until='domcontentloaded')
            else:page.set_content(fixture,wait_until='domcontentloaded')
        with sync_playwright() as p:
            binary=shutil.which('chromium') or shutil.which('google-chrome')
            opts={'headless':True}
            if binary:opts['executable_path']=binary
            browser=p.chromium.launch(**opts)
            result.update(browser=browser.version,binary=binary)
            page=browser.new_page(viewport={'width':1200,'height':900})
            page.on('pageerror',lambda e:errors.append(str(e)))
            load(page)
            page.locator('html[data-ready="true"]').wait_for()
            check('actual renderer is SVG/DOM',page.locator('html').get_attribute('data-renderer')=='svg-dom')
            before=page.screenshot(path=str(out/'desktop-start.png'),full_page=True)
            page.locator('#layers').click();check('layer control pressed',page.locator('#layers').get_attribute('aria-pressed')=='true')
            check('dial geometry moved',page.locator('#dial').get_attribute('transform')=='translate(0 -45)')
            after=page.screenshot(path=str(out/'desktop-separated.png'),full_page=True)
            check('captured pixels changed',changed(before,after))
            page.locator('#position').focus();page.keyboard.press('ArrowRight')
            check('keyboard changes range',page.locator('#position').input_value()=='51')
            check('observed vector rotation changed','2.5' in page.locator('#indicator').get_attribute('transform'))
            start=page.locator('#position').input_value()
            page.locator('#play').click();check('play enters running state',page.locator('#play').get_attribute('aria-pressed')=='true')
            page.wait_for_function('(v)=>document.getElementById("position").value!==v',arg=start)
            check('play changes actual dial position',page.locator('#position').input_value()!=start)
            page.locator('#play').click();check('pause exits running state',page.locator('#play').get_attribute('aria-pressed')=='false')
            paused=page.locator('#position').input_value();page.wait_for_timeout(200)
            check('paused position stays fixed',page.locator('#position').input_value()==paused)
            page.locator('#reset').click();check('reset position',page.locator('#position').input_value()=='50');check('reset layers',page.locator('#layers').get_attribute('aria-pressed')=='false')
            page.emulate_media(reduced_motion='reduce');page.wait_for_function('document.getElementById("play").disabled');check('reduced-motion blocks autoplay',page.locator('#play').is_disabled())
            check('direct manipulation still available',page.locator('#position').is_enabled());page.screenshot(path=str(out/'reduced-motion.png'),full_page=True)
            page.set_viewport_size({'width':390,'height':844});check('mobile no horizontal overflow',page.evaluate('document.documentElement.scrollWidth<=innerWidth'))
            page.screenshot(path=str(out/'mobile.png'),full_page=True)
            static=browser.new_page(java_script_enabled=False,viewport={'width':390,'height':844});load(static)
            check('no-JS vector visible',static.locator('#art').is_visible());check('no-JS controls hidden',not static.locator('.controls').is_visible());static.screenshot(path=str(out/'mobile-no-js.png'),full_page=True)
            check('no uncaught browser errors',not errors)
            result['status']='SVG_CONSUMER_FIXTURE_VERIFIED' if args.transport=='inline' else 'LOCAL_HTTP_SVG_CANARY_VERIFIED'
            browser.close();browser=None
        print(f'{len(checks)} browser checks passed ({args.transport} transport)')
    except Exception as exc:
        result['status']='FAIL_OR_BLOCKED_ENV';result['exception']=str(exc)
        raise
    finally:
        if browser:
            try:browser.close()
            except Exception:pass
        if server:server.shutdown();server.server_close()
        if thread:thread.join(timeout=3)
        (out/'browser-observation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
if __name__=='__main__':main()
