#!/usr/bin/env python3
"""Original, bounded vector → raster → video canary; no Adobe/Remotion claim."""
from __future__ import annotations
import argparse, hashlib, json, math, shutil, subprocess, sys
from pathlib import Path

def svg(progress: float, width: int=640, height: int=480) -> str:
    if not math.isfinite(progress) or not 0 <= progress <= 1:
        raise ValueError('progress must be finite in [0,1]')
    if any(type(v) is not int or not 16<=v<=4096 for v in (width,height)):
        raise ValueError('invalid canvas size')
    angle=-125+250*progress
    ticks=''.join(f'<path d="M320 85v12" transform="rotate({a} 320 240)"/>' for a in range(-125,126,10))
    return f"""<svg xmlns="http://www.w3.org/2000/svg" width="{width}" height="{height}" viewBox="0 0 640 480" role="img" aria-labelledby="title desc">
<title id="title">PhenoDesign control specimen</title><desc id="desc">Editable vector layers: housing, ticks, dial and indicator. No fonts or external assets.</desc>
<defs><linearGradient id="case" x2=".7" y2="1"><stop stop-color="#35383c"/><stop offset="1" stop-color="#0f1012"/></linearGradient>
<radialGradient id="surface" cx="35%" cy="25%"><stop stop-color="#b3d8d4"/><stop offset="1" stop-color="#7ebab5"/></radialGradient></defs>
<g id="background"><rect width="640" height="480" fill="#f6f5f5"/></g>
<g id="housing"><rect x="60" y="38" width="520" height="408" rx="45" fill="url(#case)"/>
<rect x="68" y="46" width="504" height="392" rx="39" fill="none" stroke="#595c60"/></g>
<g id="ticks" stroke="#d6d6d6" stroke-width="2">{ticks}</g>
<g id="dial"><circle cx="320" cy="240" r="127" fill="#090b0c"/>
<circle cx="320" cy="236" r="118" fill="url(#surface)"/><circle cx="320" cy="236" r="109" fill="none" stroke="#d6e8e6" opacity=".55"/></g>
<g id="indicator" transform="rotate({angle:.8f} 320 240)"><rect x="314" y="125" width="12" height="50" rx="6" fill="#f6f5f5"/></g>
<g id="fasteners" fill="#686b6e"><circle cx="90" cy="68" r="4"/><circle cx="550" cy="68" r="4"/><circle cx="90" cy="416" r="4"/><circle cx="550" cy="416" r="4"/></g>
</svg>"""

def run(argv: list[str], timeout: int=90) -> subprocess.CompletedProcess:
    return subprocess.run(argv,check=True,capture_output=True,text=True,timeout=timeout)

def main() -> None:
    ap=argparse.ArgumentParser(description=__doc__); ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    out=a.out.expanduser().resolve()
    if out.exists() and any(out.iterdir()): raise SystemExit('refusing non-empty output directory')
    out.mkdir(parents=True,exist_ok=True)
    for tool in ['ffmpeg','ffprobe']:
        if not shutil.which(tool): raise SystemExit(f'BLOCKED_DEPENDENCY: {tool}')
    try: import cairosvg
    except ImportError: raise SystemExit('BLOCKED_DEPENDENCY: cairosvg (install in the approved Python environment)')
    frames=out/'frames';frames.mkdir(exist_ok=True)
    source=svg(.5);(out/'editable-master.svg').write_text(source,encoding='utf-8')
    versions={}
    if shutil.which('inkscape'):
        versions['inkscape']=run(['inkscape','--version']).stdout.strip()
        run(['inkscape',str(out/'editable-master.svg'),'--export-type=png',f'--export-filename={out/"inkscape-preview.png"}'])
    for i in range(48):
        cairosvg.svg2png(bytestring=svg(i/47).encode(),write_to=str(frames/f'{i:04d}.png'))
    video=out/'vector-motion.mp4'
    run(['ffmpeg','-v','error','-n','-framerate','24','-i',str(frames/'%04d.png'),'-frames:v','48','-c:v','libx264','-threads','1','-pix_fmt','yuv420p','-movflags','+faststart',str(video)])
    probe=json.loads(run(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(video)]).stdout)
    stream=next(s for s in probe['streams'] if s['codec_type']=='video')
    assert (stream['width'],stream['height'])==(640,480)
    assert int(stream['nb_read_frames'])==48
    assert abs(float(probe['format']['duration'])-2.0)<.05
    assert stream['r_frame_rate']=='24/1'
    run(['ffmpeg','-v','error','-i',str(video),'-f','null','-'])
    assert (frames/'0000.png').read_bytes()!=(frames/'0047.png').read_bytes()
    versions['ffmpeg']=run(['ffmpeg','-version']).stdout.splitlines()[0]
    versions['ffprobe']=run(['ffprobe','-version']).stdout.splitlines()[0]
    receipt={'status':'VECTOR_RASTER_VIDEO_CANARY_VERIFIED','renderer':'CairoSVG image sequence + FFmpeg; optional independent Inkscape still',
             'frames':48,'fps':24,'durationSeconds':2,'dimensions':[640,480],'fullDecode':True,'nativeAdobe':False,'remotion':False,'versions':versions,
             'files':[{ 'path':p.relative_to(out).as_posix(),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file()]}
    (out/'observation.json').write_text(json.dumps(receipt,indent=2),encoding='utf-8')
    print(json.dumps({'out':str(out),'status':receipt['status'],'frames':48},indent=2))
if __name__=='__main__': main()
