#!/usr/bin/env python3
"""Install original 2D/3D skills into project-local Codex/ForgeCode directories. Dry-run by default."""
from __future__ import annotations
import argparse,json,re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
def inventory():
    rows={}
    for base in [ROOT/'skills',ROOT/'frontend-3d-v1/skills']:
        for p in sorted(base.glob('*/SKILL.md')):
            if not re.fullmatch(r'[a-z0-9]+(?:-[a-z0-9]+)*',p.parent.name):raise ValueError('invalid skill identifier')
            rows[p.parent.name]=(p,base.parent)
    return rows

def plan(project:Path,harness:str,names:list[str]|None=None):
    project=project.absolute()
    if not project.is_dir():raise ValueError('project directory must already exist')
    rows=inventory();names=names or list(rows);ops=[]
    for engine in (['codex','forge'] if harness=='both' else [harness]):
        if engine not in ('codex','forge'):raise ValueError('unknown harness')
        base=project/('.agents/skills' if engine=='codex' else '.forge/skills')
        for name in names:
            if name not in rows:raise ValueError('unknown original skill: '+name)
            source,kit=rows[name];dest=base/name/'SKILL.md'
            for p in [source,dest,*dest.parents]:
                if p.is_symlink():raise ValueError('symlink source/destination refused')
                if p!=source and p!=dest and p.exists() and not p.is_dir():raise ValueError('destination parent not a directory')
            text=source.read_text(encoding='utf-8').replace('{{KIT_ROOT}}',str(kit))
            text+='\n\n## Resource root for this installed copy\n\nResolve package-relative docs/resources/adapters against `'+str(kit)+'`.\nKeep that source directory available; do not treat its example reports as current repo proof.\n'
            status='IDENTICAL' if dest.is_file() and dest.read_text(encoding='utf-8')==text else 'CONFLICT' if dest.exists() else 'CREATE'
            ops.append({'source':str(source),'destination':str(dest),'status':status,'text':text})
    return ops

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--project',required=True,type=Path);p.add_argument('--harness',required=True,choices=['codex','forge','both']);p.add_argument('--skills',nargs='+');p.add_argument('--apply',action='store_true');a=p.parse_args()
    try:ops=plan(a.project,a.harness,a.skills)
    except ValueError as e:raise SystemExit(str(e))
    print(json.dumps([{k:v for k,v in x.items() if k!='text'} for x in ops],indent=2))
    if any(x['status']=='CONFLICT' for x in ops):raise SystemExit('Conflicts found. No writes; reconcile existing skills first.')
    if not a.apply:return
    created=[]
    try:
        for x in ops:
            if x['status']!='CREATE':continue
            q=Path(x['destination']);q.parent.mkdir(parents=True,exist_ok=True)
            with q.open('x',encoding='utf-8') as f:f.write(x['text'])
            created.append((q,x['text']))
    except Exception:
        for q,text in reversed(created):
            if not q.is_symlink() and q.read_text(encoding='utf-8')==text:q.unlink()
        raise
    print('Applied. Verify discovery in your installed harness/fork. No AGENTS.md or global config was changed.')
if __name__=='__main__':main()
