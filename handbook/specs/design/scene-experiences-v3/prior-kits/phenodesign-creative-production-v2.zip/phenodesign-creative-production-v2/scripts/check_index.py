from pathlib import Path
from playwright.sync_api import sync_playwright
import json, re, shutil
R=Path(__file__).resolve().parents[1]
import argparse
ap=argparse.ArgumentParser(description='Validate the bundled offline index as an inline browser fixture, not a deployed site')
ap.add_argument('--out',required=True,type=Path)
args=ap.parse_args();out=args.out.resolve()
if out.exists() and any(out.iterdir()):raise SystemExit('refusing nonempty output directory')
out.mkdir(parents=True,exist_ok=True)
checks=[]
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,executable_path=shutil.which('chromium'))
    page=b.new_page(viewport={'width':1250,'height':950});page.set_content((R/'index.html').read_text())
    assert page.locator('h1').is_visible();checks.append('offline index renders')
    assert page.locator('.skills article').count()==22;checks.append('22 new skill cards render')
    page.screenshot(path=str(out/'index-desktop.png'),full_page=False)
    page.locator('#search').fill('illustrator')
    page.wait_for_function("document.querySelector('#result').textContent.includes('matching')")
    visible=page.locator('.skills article:visible').count();assert visible>=1;checks.append('resource search filters visible matching skills')
    page.set_viewport_size({'width':390,'height':844});page.locator('#search').fill('')
    assert page.evaluate('document.documentElement.scrollWidth<=innerWidth');checks.append('mobile index avoids viewport horizontal overflow')
    page.screenshot(path=str(out/'index-mobile.png'),full_page=False)
    b.close()
(out/'index-observation.json').write_text(json.dumps({'status':'INLINE_INDEX_CHECKED','transport':'inline','checks':checks,'deployedSiteVerified':False},indent=2))
print(len(checks),'index checks passed')
