#!/usr/bin/env python3
"""Check shipped bytes. Integrity is not proof of origin, rights or runtime success."""
from pathlib import Path,PurePosixPath
import hashlib,re
ROOT=Path(__file__).resolve().parents[1]
def main():
    manifest=ROOT/'MANIFEST.sha256';seen=set();count=0
    for line in manifest.read_text(encoding='utf-8').splitlines():
        expected,name=line.split('  ',1);p=PurePosixPath(name)
        if not re.fullmatch('[a-f0-9]{64}',expected) or p.is_absolute() or '..' in p.parts or name in seen:raise SystemExit('invalid manifest row')
        seen.add(name);q=ROOT.joinpath(*p.parts)
        if q.is_symlink() or not q.is_file():raise SystemExit('missing/unsafe file: '+name)
        if hashlib.sha256(q.read_bytes()).hexdigest()!=expected:raise SystemExit('checksum mismatch: '+name)
        count+=1
    print(f'{count} packaged file checksums verified; no runtime claims inferred')
if __name__=='__main__':main()
