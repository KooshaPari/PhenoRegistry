import unittest, tempfile, importlib.util
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pd_skills',ROOT/'scripts/sync_skills.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
class SkillsTest(unittest.TestCase):
    def test_original_inventory(self):self.assertEqual(len(m.inventory()),40)
    def test_dry_run_both(self):
        with tempfile.TemporaryDirectory() as p:
            ops=m.plan(Path(p),'both',['pd-vector-svg']);self.assertEqual(len(ops),2);self.assertFalse(any(Path(p).iterdir()))
    def test_existing_skill_conflict(self):
        with tempfile.TemporaryDirectory() as p:
            root=Path(p);dest=root/'.agents/skills/pd-vector-svg/SKILL.md';dest.parent.mkdir(parents=True);dest.write_text('my skill')
            self.assertEqual(m.plan(root,'codex',['pd-vector-svg'])[0]['status'],'CONFLICT')
    def test_unknown_skill_rejected(self):
        with tempfile.TemporaryDirectory() as p:
            with self.assertRaises(ValueError):m.plan(Path(p),'forge',['../escape'])
if __name__=='__main__':unittest.main()
