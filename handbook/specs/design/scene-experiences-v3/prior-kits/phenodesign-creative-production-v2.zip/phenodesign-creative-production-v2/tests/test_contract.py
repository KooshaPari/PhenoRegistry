import json, unittest, copy
from pathlib import Path
from jsonschema import Draft202012Validator, ValidationError
ROOT=Path(__file__).resolve().parents[1]
class ContractTest(unittest.TestCase):
    def setUp(self):
        self.schema=json.loads((ROOT/'contracts/creative-extension.schema.json').read_text())
        self.sample=json.loads((ROOT/'contracts/example.extension.json').read_text())
        self.v=Draft202012Validator(self.schema)
    def test_schema_is_valid(self):Draft202012Validator.check_schema(self.schema)
    def test_sample_is_valid(self):self.v.validate(self.sample)
    def test_hash_shape_rejected(self):
        self.sample['source']['sha256']='PASS'
        with self.assertRaises(ValidationError):self.v.validate(self.sample)
    def test_unknown_status_rejected(self):
        self.sample['verification']['consumer']='looks-good'
        with self.assertRaises(ValidationError):self.v.validate(self.sample)
    def test_missing_rights_rejected(self):
        del self.sample['rights']
        with self.assertRaises(ValidationError):self.v.validate(self.sample)
if __name__=='__main__':unittest.main()
