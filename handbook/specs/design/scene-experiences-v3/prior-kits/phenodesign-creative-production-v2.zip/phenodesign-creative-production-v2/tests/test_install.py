import unittest, tempfile, json, hashlib, importlib.util, sys
from pathlib import Path
from unittest.mock import patch
ROOT=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('pd_install',ROOT/'integration/apply_overlay.py')
i=importlib.util.module_from_spec(spec);sys.modules[spec.name]=i;spec.loader.exec_module(i)
class InstallTest(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.root=Path(self.tmp.name);self.repo=self.root/'repo';self.pack=self.root/'pack'
        self.repo.mkdir();self.pack.mkdir();(self.repo/'package.json').write_text('{"name":"@phenotype/design"}')
        self.data=b'new content';(self.pack/'new.txt').write_bytes(self.data)
        self.m={'files':[{'source':'new.txt','target':'creative/a.txt','sha256':hashlib.sha256(self.data).hexdigest()}]}
    def tearDown(self):self.tmp.cleanup()
    def test_dry_run_does_not_write(self):
        self.assertEqual(i.plan(self.repo,self.pack,self.m)[0].action,'ADD');self.assertFalse((self.repo/'creative').exists())
    def test_apply_is_idempotent(self):
        i.apply(self.repo,self.pack,self.m);self.assertEqual(i.apply(self.repo,self.pack,self.m)[0].action,'UNCHANGED')
    def test_existing_conflict_is_preserved(self):
        (self.repo/'creative').mkdir();(self.repo/'creative/a.txt').write_text('mine')
        with self.assertRaises(i.Conflict):i.apply(self.repo,self.pack,self.m)
        self.assertEqual((self.repo/'creative/a.txt').read_text(),'mine')
    def test_exact_blob_replacement(self):
        (self.repo/'creative').mkdir();(self.repo/'creative/a.txt').write_bytes(b'old')
        self.m['files'][0]['expected_git_blob']=i.blob_sha(b'old')
        i.apply(self.repo,self.pack,self.m);self.assertEqual((self.repo/'creative/a.txt').read_bytes(),self.data)
    def test_wrong_blob_blocks_before_changes(self):
        (self.repo/'creative').mkdir();(self.repo/'creative/a.txt').write_bytes(b'old')
        self.m['files'][0]['expected_git_blob']='a'*40
        with self.assertRaises(i.Conflict):i.apply(self.repo,self.pack,self.m)
    def test_wrong_repo_rejected(self):
        (self.repo/'package.json').write_text('{"name":"other"}')
        with self.assertRaises(i.Conflict):i.plan(self.repo,self.pack,self.m)
    def test_source_tampering_rejected(self):
        (self.pack/'new.txt').write_bytes(b'changed')
        with self.assertRaises(i.Conflict):i.plan(self.repo,self.pack,self.m)
    def test_traversal_rejected(self):
        self.m['files'][0]['target']='../escape'
        with self.assertRaises(i.Conflict):i.plan(self.repo,self.pack,self.m)
    def test_symlink_destination_parent_rejected(self):
        (self.repo/'creative').symlink_to(self.pack,target_is_directory=True)
        with self.assertRaises(i.Conflict):i.plan(self.repo,self.pack,self.m)
    def test_second_write_failure_rolls_back(self):
        self.m['files'].append(dict(self.m['files'][0],target='creative/b.txt'))
        real=i.atomic_write;calls=0
        def broken(p,d):
            nonlocal calls
            calls+=1
            if calls==2:raise OSError('fixture disk failure')
            real(p,d)
        with patch.object(i,'atomic_write',broken):
            with self.assertRaises(OSError):i.apply(self.repo,self.pack,self.m)
        self.assertFalse((self.repo/'creative').exists());self.assertFalse((self.repo/'.phenodesign-creative-overlay.lock').exists())
    def test_preexisting_lock_not_removed(self):
        lock=self.repo/'.phenodesign-creative-overlay.lock';lock.write_text('someone else')
        with self.assertRaises(FileExistsError):i.apply(self.repo,self.pack,self.m)
        self.assertEqual(lock.read_text(),'someone else')
if __name__=='__main__':unittest.main()
