# PhenoDesign creative production • v2

This supersedes the *scope* of the frontend/3D starter; it preserves the entire
v1 kit unchanged under `frontend-3d-v1/`. Target: **KooshaPari/PhenoDesign**.

## The assignment

Build an agent-operated design studio, not a folder of rotating-object demos.
Cover vector and raster art, layout/brand/UI, 2.5D, editable 3D, interactive
props and scenes, motion graphics, video, diagrams, data visualization and
media delivery. Photoshop and Illustrator on the operator's device are
first-class authoring tools. Other local tools can be acquired and qualified
when they improve the actual brief. No cloud-only assumption, no Docker
requirement, no new umbrella repository or competing evidence registry.

## Start in this order

1. `AGENT-HANDOFF.md`: the execution assignment and completion contract.
2. `docs/REPO-AUDIT.md`: actual branch findings, hashes, and ownership caveats.
3. `docs/CAPABILITY-MAP.md`: all medium families and their source/export/tests.
4. `docs/PIPELINE-AND-E2E.md`: the shared lifecycle and acceptance matrix.
5. `skills/`: original new skills. Also retain relevant v1 skills.
6. `integration/`: additive repo overlay plus guarded renderer replacement.
7. `examples/`: executable SVG/animation pipeline and Remotion composition source.
8. `resources/catalog.json` and `resources/SOURCES.md`: primary references.

## Local checks

```sh
node --test tests/*.test.mjs
python -m unittest discover -s tests -p 'test_*.py' -v
python scripts/build_vector_canary.py --out /absolute/new/output-directory
python scripts/browser_canary.py --out /absolute/new/browser-evidence-directory
python scripts/verify_package.py
python scripts/sync_skills.py --project /existing/project --harness both
```

The Python vector path uses the installed Inkscape CLI (or CairoSVG), then
FFmpeg/ffprobe. Browser tests use Python Playwright and an installed Chromium.
They do not exercise Adobe, Blender, or Remotion. This environment blocked
local HTTP/file navigation; the recorded passing browser run used explicit
`--transport inline`, which validates the fixture, not a deployed website. Read `evidence/VALIDATION.md`
for actual execution boundaries. Native-tool recipes are not runtime proof.

## Integrate into the real repo

```sh
python integration/apply_overlay.py --repo /path/to/PhenoDesign
# Inspect the dry-run, refresh the migration branch and source hashes.
python integration/apply_overlay.py --repo /path/to/PhenoDesign --apply
```

The overlay extends existing `remotion/doc-embeds`, and places the reusable
creative canary/skills/docs in `creative-production/`. It refuses modified
replacement files and conflicting destinations. It never merges PRs,
publishes, installs software, or updates the repository's authority documents.
Preserve existing tokens, package exports, Vue/React boundaries and consumers.

`index.html` is the offline entry point. The gallery has no external assets,
font downloads, analytics or package-CDN dependency.
