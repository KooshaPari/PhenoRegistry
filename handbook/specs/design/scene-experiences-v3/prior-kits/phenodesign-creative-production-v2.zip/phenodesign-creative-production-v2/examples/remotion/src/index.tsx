import React from 'react';
import {AbsoluteFill, Composition, registerRoot, useCurrentFrame, useVideoConfig} from 'remotion';
/** Original deterministic reference; no dependency install/runtime claim is made. */
export const DialFilm: React.FC = () => {
  const frame=useCurrentFrame();const {durationInFrames}=useVideoConfig();
  const p=Math.max(0,Math.min(1,frame/Math.max(1,durationInFrames-1)));
  const angle=-125+250*p;
  return <AbsoluteFill style={{background:'#f6f5f5',justifyContent:'center',alignItems:'center'}}>
    <svg viewBox="0 0 800 600" width="100%" height="100%" role="img" aria-label="A control dial turns from low to high">
      <rect x="90" y="90" width="620" height="420" rx="44" fill="#0f1012"/>
      <circle cx="400" cy="300" r="147" fill="#7ebab5"/>
      <g transform={`rotate(${angle} 400 300)`}><rect x="393" y="160" width="14" height="63" rx="7" fill="#f6f5f5"/></g>
    </svg>
  </AbsoluteFill>;
};
const Root:React.FC=()=> <Composition id="DialFilm" component={DialFilm} durationInFrames={120} fps={30} width={800} height={600}/>;
registerRoot(Root);
