# Deterministic reference composition

This is an original canary, **not a tested Remotion render** in this package.
Integrate it into the existing PhenoDesign `remotion/doc-embeds` workspace or
a temporary branch of that workspace, retaining compatible locked versions.

After its actual dependency/browser/license qualification:

```sh
# In the prepared Remotion package, using the installed local CLI:
# entry-point = path to this src/index.tsx, composition id = DialFilm
# render 120 frames / 30 fps / 800x600, then ffprobe and full decode.
```

Check frames 0, 60 and 119; seek in reverse and compare the same frames.
Require a correct 4-second, 800×600 output; decode all frames and test the
result in the real documentation embed. Add R3F, Lottie or Rive only after
this simple path passes. No package version is invented here: resolve the
current compatible family in the target's existing lockfile.
