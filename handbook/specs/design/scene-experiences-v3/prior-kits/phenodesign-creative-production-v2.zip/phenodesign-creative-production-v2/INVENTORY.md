# Inventory

The package contains **22 new original skills** plus **18 original frontend/3D
skills** preserved from v1: **40 original skills** total. The existing licensed
Anthropic frontend-design snapshot is also preserved separately.

The new catalog has **33 annotated primary-resource records** and a **23-family
capability map**. V1's original 36-resource collection is retained separately;
these are catalog entries, not a claim that all URLs are unique or all tools were
runtime tested. Current acquisition/qualification notes accompany each entry.

Core contents: agent handoff; on-device Adobe guide and three original native
scripts; editable 2D canary source, PNGs and actual video; interactive SVG consumer;
original Remotion composition source; source-aware PhenoDesign audit; guarded
renderer overlay; local installer and skill-discovery sync; test code and retained
evidence; proposed creative metadata extension; original v1 3D demo/source assets;
searchable offline index; licenses, provenance and integrity manifest.

`integration/manifest.json` records the exact local integration payload.
`MANIFEST.sha256` covers shipped file bytes except itself. This package is not
an installed PhenoDesign service and does not certify all listed media backends.
