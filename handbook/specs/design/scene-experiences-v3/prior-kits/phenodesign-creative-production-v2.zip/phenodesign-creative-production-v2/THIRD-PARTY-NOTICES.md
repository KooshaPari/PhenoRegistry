# Rights and provenance

Original v2 code and guidance are under the root MIT license. The entire prior
frontend/3D kit is preserved at `frontend-3d-v1/` under its original notices and
licenses. That subtree includes the previously collected Anthropic frontend-design
skill and its Apache-2.0 license, not a new relicensing claim.

Remotion's upstream skill repository is linked for acquisition from its official
source. No unverified redistribution permission is inferred from being on GitHub.
Adobe, Remotion, Blender, Rive, and other application/runtime/model/asset licenses
must be checked separately for actual use. These programs are not included here.

No font binaries, proprietary Adobe projects from the user's device, credentials,
commercial stock, scanned products, or full copies of third-party documentation
are bundled. Native JSX examples and the Remotion specimen are original canaries.
Apple/Nike references are interaction inspiration, not copied brand/trade dress.

Source metadata and inspection limitations are in `resources/`. The local overlay
contains original replacement/helper code targeting inspected PhenoDesign paths;
no Git commit, merge, remote write or native-device execution occurred here.
