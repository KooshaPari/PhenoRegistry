# Execute: fill out PhenoDesign as the creative production and review surface

You are implementing in **KooshaPari/PhenoDesign**, not opening a new product.
The user's scope is **all practical 2D/2.5D/3D and time-based forms**, with
Illustrator and Photoshop already reported on device. Source other tools as
needed within existing approvals; do not stop because they were absent in
the preparation environment. Do not claim device availability until probed.

## First: reconcile, do not duplicate

Refresh main, PR #87 and its source migration. Snapshot in this pack:
main/base `d11733b1525cb97e045dc7f8d67a05df5501f6c1`; PR head
`6c99a15337505b55f46a9f576465db5e4053b416`. PR #87 was **open, not merged**.
The imported Vue journey components, Playwright recorders and Remotion code
are the baseline to extend. Rust migration is separately described by that
PR as phenotype-tooling #358; verify its actual state, don't recreate it.

The repo description refers to asset-engine, while the user requests a
complete PhenoDesign surface. Preserve this distinction: one coherent
PhenoDesign API/UI/skills catalog can call separately owned workers. Resolve
the worker's current home before moving source. A stale archived README is
not authority to discard the active repo or to restore deleted repositories.

## Deliver vertical slices, not installed-tool counts

A vertical slice is brief → rights-cleared inputs → editable source → export
→ real consuming surface → semantic and pixel tests → independent critique
→ revision → reproducible receipt. Every supported medium needs this chain.

Start by running the included dependency-light vector slice and regression
checks. Then complete native Illustrator and Photoshop canaries on the
approved host session. Complete one Blender → GLB → interactive page slice,
one Remotion → decoded video → real documentation embed slice, and one
stateful 2D animation slice. Extend to the rest of CAPABILITY-MAP using the
same contracts, without loading all backends into every agent context.

## Native tools

Probe version, host platform, license/login state, fonts (names and rights,
not copied binaries), plugins, automation APIs, filesystem approvals,
session isolation and resource leases. For Illustrator, probe its **official
Beta MCP server** first if that app is installed/approved; retain JSX/SDK
routes for deterministic jobs and stable Illustrator. Do not assume Beta is
installed or install it over stable without the existing approval process.
For Photoshop use supported UXP/DOM + batchPlay, or a qualified JSX path.
An AI Assistant panel is not automatically an external automation API.

Prefer a bounded script or native tool call to blind desktop clicking.
If GUI actions are unavoidable, use an instance-bound isolated session.
No focus theft, operator-document edits, personal browser capture, microphone
routing, broad credential forwarding, or global process killing. One lease
per native app instance until isolation/concurrency is demonstrated. Preserve
native .ai/.psd/.blend masters; export and **reopen** them before acceptance.

## Install and acquire intentionally

Check existing tools/cache first. Official distribution or documented source,
record exact version/commit/hash, tool/model/asset license and disk/VRAM cost.
Prefer project-local dependencies and a minimal environment. No blind
curl-to-shell, unreviewed skill execution, floating production pins, hidden
telemetry or uploading private source to a generation service by default.
Do not turn reversible, preauthorized local setup into needless questions;
record a precise blocker for genuinely missing rights, credentials or spend.

## Repo integration work

Apply `integration/` after rechecking its preconditions. Extend existing
contracts at explicit version boundaries rather than defining a second
canonical Journey/BundleManifest. Reuse the actual recorder, CLI verifier,
viewer, external worker broker and design token owner. Carry source pixels,
fit/crop/zoom and time ranges through the evidence-to-presentation transform.
Keep media masters immutable; presentation annotations do not rewrite proof.

Harden the current Remotion staging/renderer; test same-basename assets,
concurrent jobs, symlink escape, invalid input, cancelled/failed child process,
missing encoder, absent frames, wrong duration and bad annotation geometry.
Pin compatible Remotion-family versions in the real lockfile. Add workspace
scripts/CI for imported packages without silently changing public exports.

## Acceptance and reporting

Use existing lifecycle vocabulary. In receipts separately report AVAILABLE,
SOURCE_INSPECTED, CANARY_VERIFIED, CONSUMER_VERIFIED and any BLOCKED state;
these are capability observations, not replacement project statuses.
Report exact files changed; medium/capability coverage; test commands and
artifacts; native source reopen results; source hashes; environment; semantic,
visual, accessibility and performance results; failures; and next ready work.
A self-authored PASS or a hash is not independent verification. Never label
all forms E2E-complete just because the architecture lists them.

Challenge your selected tool: a SVG might beat a 3D hero; Blender might beat
image-to-3D; Remotion might lose to a simple FFmpeg derivative; existing code
might beat a new service. Compare at least two plausible alternatives against
the brief and retain the deciding evidence. Then execute the chosen route.
