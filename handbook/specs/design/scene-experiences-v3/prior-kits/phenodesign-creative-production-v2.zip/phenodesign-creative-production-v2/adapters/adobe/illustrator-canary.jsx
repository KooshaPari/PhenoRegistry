#target illustrator
/* Native host canary. Run only in an approved isolated Illustrator session.
   Set PHENODESIGN_JOB_DIR to an existing empty directory before app startup,
   or define PD_JOB_DIR in an approved native-script wrapper before evaluation.
   Source and native execution are NOT verified by this package's Linux tests. */
(function () {
  var raw = (typeof PD_JOB_DIR !== 'undefined') ? PD_JOB_DIR : $.getenv('PHENODESIGN_JOB_DIR');
  if (!raw) throw new Error('PHENODESIGN_JOB_DIR is required');
  var dir = new Folder(raw); if (!dir.exists) throw new Error('job directory must exist');
  var ai = new File(dir.fsName+'/canary.ai'), png = new File(dir.fsName+'/canary.png'), svg = new File(dir.fsName+'/canary.svg');
  if (ai.exists||png.exists||svg.exists) throw new Error('refusing existing output');
  var doc=null, reopened=null, report=null, oldLevel=app.userInteractionLevel;
  function color(r,g,b){var c=new RGBColor();c.red=r;c.green=g;c.blue=b;return c;}
  try {
    app.userInteractionLevel=UserInteractionLevel.DONTDISPLAYALERTS;
    doc=app.documents.add(DocumentColorSpace.RGB,640,480);
    doc.layers[0].name='Housing';
    var box=doc.pathItems.roundedRectangle(400,80,480,300,28,28);
    box.fillColor=color(15,16,18);box.stroked=false;
    var face=doc.layers.add();face.name='Dial';doc.activeLayer=face;
    var circle=doc.pathItems.ellipse(355,205,230,230);circle.fillColor=color(126,186,181);circle.stroked=false;
    var indicator=doc.layers.add();indicator.name='Indicator';doc.activeLayer=indicator;
    var mark=doc.pathItems.rectangle(347,313,14,65);mark.fillColor=color(246,245,245);mark.stroked=false;
    var save=new IllustratorSaveOptions();save.pdfCompatible=true;
    doc.saveAs(ai,save);
    var p=new ExportOptionsPNG24();p.transparency=true;p.artBoardClipping=true;doc.exportFile(png,ExportType.PNG24,p);
    var s=new ExportOptionsSVG();doc.exportFile(svg,ExportType.SVG,s);
    doc.close(SaveOptions.DONOTSAVECHANGES);doc=null;
    reopened=app.open(ai);
    if(reopened.layers.length!==3)throw new Error('saved source lost editable layers');
    if(reopened.pathItems.length<3)throw new Error('saved source lost paths');
    var names=[];for(var i=0;i<reopened.layers.length;i++)names.push(reopened.layers[i].name);
    report=new File(dir.fsName+'/native-observation.txt');report.open('w');
    report.writeln('adapter=illustrator-jsx');report.writeln('version='+app.version);
    report.writeln('sourceReopened=true');report.writeln('layers='+names.join(','));
    report.writeln('status=CANARY_SOURCE_REOPENED; independent visual and consumer verification still required');report.close();report=null;
  } finally {
    if(report)try{report.close();}catch(e){}
    if(reopened)try{reopened.close(SaveOptions.DONOTSAVECHANGES);}catch(e){}
    if(doc)try{doc.close(SaveOptions.DONOTSAVECHANGES);}catch(e){}
    app.userInteractionLevel=oldLevel;
  }
})();
