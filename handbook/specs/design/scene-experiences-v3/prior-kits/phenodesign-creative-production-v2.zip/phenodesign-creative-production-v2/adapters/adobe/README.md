# Native authoring canaries

See `../../docs/ADOBE-ON-DEVICE.md` before execution. These scripts require
Adobe's actual native application and a reserved session. They are not a
cloud API, standalone Linux process, or certified unattended desktop worker.

Create a fresh job directory. Supply its absolute path in
`PHENODESIGN_JOB_DIR` before app startup, or a reviewed `PD_JOB_DIR` wrapper.
Invoke through the approved native worker or the application's scripting
interface. Use different job directories for Illustrator and Photoshop.
Scripts refuse existing outputs. They never iterate through and close all
open documents. A successful native receipt still needs capture, visual and
consumer verification. These probes use geometry only and bundle no fonts.

The official Illustrator Beta MCP setup must use the endpoint and key from
the actual installed app. Do not paste credentials into this package.
