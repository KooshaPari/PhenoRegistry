#target photoshop
/* Legacy JSX native host canary. Prefer the qualified local UXP adapter when available.
   Run in a reserved Photoshop instance, never the operator's working document.
   Set PHENODESIGN_JOB_DIR before host startup or PD_JOB_DIR in a reviewed wrapper. */
(function () {
  var raw=(typeof PD_JOB_DIR!=='undefined')?PD_JOB_DIR:$.getenv('PHENODESIGN_JOB_DIR');
  if(!raw)throw new Error('PHENODESIGN_JOB_DIR is required');
  var dir=new Folder(raw);if(!dir.exists)throw new Error('job directory must exist');
  var psd=new File(dir.fsName+'/canary.psd'),png=new File(dir.fsName+'/canary.png');
  if(psd.exists||png.exists)throw new Error('refusing existing output');
  var doc=null,reopened=null,oldUnits=app.preferences.rulerUnits,oldDialogs=app.displayDialogs;
  function fill(name,points,hex){var l=doc.artLayers.add();l.name=name;doc.activeLayer=l;
    var c=new SolidColor();c.rgb.hexValue=hex;doc.selection.select(points);doc.selection.fill(c);doc.selection.deselect();return l;}
  try {
    app.preferences.rulerUnits=Units.PIXELS;app.displayDialogs=DialogModes.NO;
    doc=app.documents.add(640,480,72,'PhenoDesign layered canary',NewDocumentMode.RGB,DocumentFill.TRANSPARENT);
    doc.activeLayer.name='Transparent base';
    fill('Housing',[[80,80],[560,80],[560,400],[80,400]],'0F1012');
    fill('Surface',[[170,120],[470,120],[470,360],[170,360]],'7EBAB5');
    fill('Indicator',[[314,140],[326,140],[326,220],[314,220]],'F6F5F5');
    var opt=new PhotoshopSaveOptions();opt.layers=true;doc.saveAs(psd,opt,true,Extension.LOWERCASE);
    doc.saveAs(png,new PNGSaveOptions(),true,Extension.LOWERCASE);
    doc.close(SaveOptions.DONOTSAVECHANGES);doc=null;
    reopened=app.open(psd);
    if(reopened.layers.length!==4)throw new Error('saved source lost layers');
    var names=[];for(var i=0;i<reopened.layers.length;i++)names.push(reopened.layers[i].name);
    var report=new File(dir.fsName+'/native-observation.txt');
    if(!report.open('w'))throw new Error('cannot write receipt');
    report.writeln('adapter=photoshop-jsx');report.writeln('version='+app.version);
    report.writeln('sourceReopened=true');report.writeln('layers='+names.join(','));
    report.writeln('status=CANARY_SOURCE_REOPENED; independent visual and consumer verification still required');report.close();
  } finally {
    if(reopened)try{reopened.close(SaveOptions.DONOTSAVECHANGES);}catch(e){}
    if(doc)try{doc.close(SaveOptions.DONOTSAVECHANGES);}catch(e){}
    app.preferences.rulerUnits=oldUnits;app.displayDialogs=oldDialogs;
  }
})();
