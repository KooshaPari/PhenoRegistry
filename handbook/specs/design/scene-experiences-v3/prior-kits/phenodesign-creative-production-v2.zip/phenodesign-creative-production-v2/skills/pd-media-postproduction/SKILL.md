---
name: pd-media-postproduction
description: Assemble and deliver video, image sequences, audio and caption derivatives.
license: MIT
---

# Media Postproduction

## Author

Choose the master and distribution formats from the target channel, alpha/HDR needs and source quality. Retain loss-minimizing masters and an explicit edit/transform recipe. Use FFmpeg for bounded deterministic transformations; qualify AE/other editing tools for operations that need them. Preserve audio stems and caption source when present.

## Inspect and iterate

Probe streams before processing, decode every output frame, inspect beginning/end/scene cuts, and verify aspect, frame rate, color range, audio sync and caption timing. Test playback in the real consumer and use a poster/transcript. Do not treat exit code alone as evidence of correct content.

## Deliver

Deliver source/edit recipe, master, distribution media, poster, captions/transcript and verified metadata.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
M06,M07; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
