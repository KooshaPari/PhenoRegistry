---
name: pd-creative-direction
description: Choose a distinctive visual direction and medium for a real product brief.
license: MIT
---

# Creative Direction

## Author

Extract the product, audience, placement and action. Collect a small rights-cleared reference board and write what each reference teaches: framing, light, rhythm, typography, material or interaction—not a request to clone its logo. Compare a static/vector treatment, a layered 2.5D treatment and a true 3D/film treatment against the same job. Define one dominant creative idea, hierarchy, palette roles, type roles and a motion vocabulary before detailed polish.

## Inspect and iterate

Produce a one-screen style frame, one representative state change and a low-cost export proof. Check silhouette at thumbnail size and composition without decorative effects. Critique whether the form explains the subject or could belong to any template. Iterate the weaker axis instead of adding effects everywhere.

## Deliver

Deliver the brief, selected direction, rejected alternatives with reasons, source-backed style frame and placement/quality targets. Do not rename a rough canary “Apple-level polish”.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A02,M02; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
