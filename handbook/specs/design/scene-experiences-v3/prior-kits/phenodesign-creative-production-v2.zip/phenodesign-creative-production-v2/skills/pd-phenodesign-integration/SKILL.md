---
name: pd-phenodesign-integration
description: Consolidate creative production into the existing PhenoDesign and partial journeys migration.
license: MIT
---

# Phenodesign Integration

## Author

Refresh the named repo and migration PR. Map public exports, token authority, native workers, recorder/verifier ownership and Remotion consumers before edits. Reuse existing components and adapt at explicit version boundaries. Keep PhenoDesign the coherent creative surface even when a worker lives in asset-engine or phenotype-tooling.

## Inspect and iterate

Apply guarded patches only when expected source matches; preserve concurrent fixes. Exercise actual consumer packages and imports, source provenance and rollback. Fix stale archived text and workspace wiring based on observed current ownership, not historical guesses.

## Deliver

Deliver patches, integration tests, migration mapping and unresolved ownership blockers. Do not create another independent creative registry or restore deleted projects without a need.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
R01,R02,R06; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
