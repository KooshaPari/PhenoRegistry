---
name: pd-creative-visual-e2e
description: Run structural, perceptual, interaction, accessibility and performance evaluation on produced assets.
license: MIT
---

# Creative Visual E2E

## Author

Use the current journey harness and an independent verifier boundary where available. Name the exact subject/build, renderer/device, fixtures and acceptance assertions. Test source, export and actual consuming surface as separate stages.

## Inspect and iterate

Capture real pixels; inspect semantics and physical output dimensions. Exercise keyboard/touch, resize, fast/reverse input, reduced motion, missing assets and unavailable GPU. Measure actual transfer/memory/frame timing rather than promising arbitrary scores. Keep rejected iterations and failure evidence.

## Deliver

Deliver scoped results with honest blockers. Inline browser fixture tests, native app tests, hardware GPU tests and deployed E2E are distinct statuses.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
Q01,Q02,M07; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
