---
name: pd-2d-stateful-animation
description: Create interactive 2D illustrations and controls with explicit state machines.
license: MIT
---

# 2D Stateful Animation

## Author

Define idle, hover/focus, pressed, dragging, success, error, disabled and reduced-motion behavior as applicable. Choose DOM/SVG for simple inspectable shapes; qualify Rive or another stateful runtime where richer authored transitions justify it. Enumerate state inputs and output semantics before drawing. Runtime playback alone does not prove .riv authoring.

## Inspect and iterate

Test every transition, cancellation, reentry and reset; repeat changes rapidly. Verify pointer, keyboard and touch outcomes from real rendered state. Keep semantic controls outside a decorative canvas where needed. Pause offscreen/hidden behavior and offer a stable reduced-motion representation.

## Deliver

Deliver source state graph, editable artwork, runtime integration and transition evidence. Any candidate CLI must create a file that reopens in its native editor.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
V04,Q01; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
