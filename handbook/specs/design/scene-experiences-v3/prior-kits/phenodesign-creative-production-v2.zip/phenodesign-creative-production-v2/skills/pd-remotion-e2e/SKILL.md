---
name: pd-remotion-e2e
description: Create, inspect, render and integrate Remotion media in the existing PhenoDesign package.
license: MIT
---

# Remotion E2E

## Author

Extend imported remotion/doc-embeds rather than opening a duplicate renderer project. Runtime-validate props and align exact compatible Remotion-family versions in the real lockfile. Author frame-dependent compositions. Use local scene durations, explicit readiness and seeded/controlled variability; seek simulation or timeline state instead of relying on wall time.

## Inspect and iterate

Sample first/middle/last and boundary frames, render via an installed local CLI into isolated staging, decode every frame, verify dimensions/fps/duration/audio, then test the actual documentation/video consumer. Exercise corrupt inputs, basename collisions, concurrency and cancellation. Keep source capture separate from edited presentation.

## Deliver

Deliver composition source, assets, lockfile diff, output and browser/media receipts. This pack’s deterministic example is not itself Remotion runtime proof.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
M01,M02,M03,M04,M05; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
