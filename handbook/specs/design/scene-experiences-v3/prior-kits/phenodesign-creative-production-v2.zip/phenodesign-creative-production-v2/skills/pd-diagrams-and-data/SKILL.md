---
name: pd-diagrams-and-data
description: Produce truthful semantic diagrams, charts and animated explanations.
license: MIT
---

# Diagrams And Data

## Author

Start with actual entities, relationships and data, including uncertainty. Select SVG/HTML, Graphviz/Mermaid/D3, Manim or Motion Canvas based on whether the task is navigation, data inspection or explanation. Separate data/model from layout; give machines and readers an equivalent semantic form.

## Inspect and iterate

Verify labels, values, relationship direction, legends and non-color distinctions. Test narrow/mobile layouts, reading order, navigation and animation endpoints. Never invent metrics for aesthetic density or claim a concept diagram is an observed system.

## Deliver

Deliver data/schema, layout source, generated visual and equivalent text/table/navigation.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
V06,V07,Q01; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
