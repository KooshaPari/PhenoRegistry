---
name: pd-editable-roundtrip
description: Verify source custody and editability across native files, exchange exports and runtimes.
license: MIT
---

# Editable Roundtrip

## Author

Define what must remain editable: layers, vector paths, live text, rigs, named meshes, node parameters, timeline or state graph. Save in native format and exchange format separately. Record linked inputs and portable relative paths.

## Inspect and iterate

Close/reopen only the owned source document, change a named component, re-export and compare the expected region/behavior. Check source loss that a final screenshot would hide. Test missing texture/font/link and unsupported feature conversion explicitly.

## Deliver

Deliver reopen proof and a small successful edit proof for each accepted source family. File extension and file existence are not sufficient.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A01,A05,V01; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
