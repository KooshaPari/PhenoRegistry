# New original skills

Load a small relevant subset per task; do not paste this whole library into every agent.
The original 18 3D/frontend skills remain under `frontend-3d-v1/skills/`.

- **pd-creative-direction** — Choose a distinctive visual direction and medium for a real product brief.
- **pd-illustrator-native** — Author and revise editable vector art in local Illustrator using its qualified MCP or scripting surface.
- **pd-photoshop-native** — Create layered raster composites, product imagery, masks and textures with native Photoshop automation.
- **pd-vector-svg** — Build expressive, clean 2D vector assets that stay editable and work in the frontend.
- **pd-raster-compositing** — Create and optimize raster assets, paintings, cutouts and multi-layer compositions.
- **pd-2d-stateful-animation** — Create interactive 2D illustrations and controls with explicit state machines.
- **pd-canvas-sprites-particles** — Author performant 2D canvas scenes, sprites and interactive particle props.
- **pd-layered-2-5d** — Create dimensional design from layered 2D sources without pretending it is a reusable 3D model.
- **pd-motion-creative** — Design motion as staged visual explanation, not scattered transitions.
- **pd-remotion-e2e** — Create, inspect, render and integrate Remotion media in the existing PhenoDesign package.
- **pd-media-postproduction** — Assemble and deliver video, image sequences, audio and caption derivatives.
- **pd-journey-to-presentation** — Transform actual journey evidence into annotated media without altering what it proves.
- **pd-editable-roundtrip** — Verify source custody and editability across native files, exchange exports and runtimes.
- **pd-color-material-pipeline** — Keep color, alpha and material appearance coherent from authoring through final delivery.
- **pd-typography-layout** — Create readable, distinctive typography and layout across UI, illustration, video and print.
- **pd-diagrams-and-data** — Produce truthful semantic diagrams, charts and animated explanations.
- **pd-print-production** — Prepare print and packaging assets as a qualified delivery lane.
- **pd-local-generation** — Acquire and use local image/3D generation as an optional authoring aid.
- **pd-tool-acquisition** — Source needed tools and skills without turning a design job into an unbounded install spree.
- **pd-native-worker-isolation** — Operate native Adobe/Blender/engine tools without disturbing the operator.
- **pd-creative-visual-e2e** — Run structural, perceptual, interaction, accessibility and performance evaluation on produced assets.
- **pd-phenodesign-integration** — Consolidate creative production into the existing PhenoDesign and partial journeys migration.

## Project-local discovery

```sh
python scripts/sync_skills.py --project /existing/project --harness both
python scripts/sync_skills.py --project /existing/project --harness both --apply
```

The default includes all 40 original v1/v2 skills in discovery directories, not
all in each model context. Select a subset with `--skills`. Conflicts stop writes;
existing AGENTS.md and global settings are untouched. Copies point back to the
canonical package resource root. Verify discovery in local Codex/ForgeCode forks.
The third-party frontend-design snapshot remains optional and separately licensed.
