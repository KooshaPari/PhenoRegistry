---
name: pd-canvas-sprites-particles
description: Author performant 2D canvas scenes, sprites and interactive particle props.
license: MIT
---

# Canvas Sprites Particles

## Author

Decide whether Canvas/PixiJS actually improves on DOM/SVG. Design an atlas with pivots, logical bounds, padding and timing metadata; retain source layers. Bound particles, overdraw and resolution. Keep input coordinates separate from backing-store pixels and account for device pixel ratio and resize.

## Inspect and iterate

Exercise picking/hit areas, keyboard equivalents, offscreen pause, context/resource cleanup and atlas edge bleeding. Test on an actual low-tier target rather than using an accelerated desktop as universal evidence. Record draw calls/transfer/memory where available.

## Deliver

Deliver art sources, atlas/metadata, controls, fallback and measured consumer behavior. Do not put required instructions only into pixels.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
V05,Q01; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
