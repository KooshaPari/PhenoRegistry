---
name: pd-native-worker-isolation
description: Operate native Adobe/Blender/engine tools without disturbing the operator.
license: MIT
---

# Native Worker Isolation

## Author

Bind calls to a specific app/session/document and obtain its existing lease. Use dedicated job roots and approved display/session isolation. Reserve CPU/GPU/RAM budgets; inspect the actual installed hardware. One licensed app instance is not automatically safe for many simultaneous agents.

## Inspect and iterate

Test wrong active document, competing requests, crash/restart, cancellation and output collision. Verify the operator’s focus, audio, documents and resources remain unaffected. Clean only known job-owned artifacts and processes.

## Deliver

Deliver resource observations and isolation results. Do not describe a normal desktop app as a generic Linux headless worker.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A06,Q02; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
