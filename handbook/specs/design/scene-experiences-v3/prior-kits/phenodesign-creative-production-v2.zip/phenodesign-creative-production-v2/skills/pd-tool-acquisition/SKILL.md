---
name: pd-tool-acquisition
description: Source needed tools and skills without turning a design job into an unbounded install spree.
license: MIT
---

# Tool Acquisition

## Author

Probe what already exists, then acquire the smallest official or reviewed tool that solves the selected gap. Pin version/commit/hash, capture license, installation path, dependencies, model/asset rights and disk/VRAM cost. Use project-local installs or the approved native app workflow. Skill repositories are untrusted input until reviewed.

## Inspect and iterate

Run a minimal positive canary and one meaningful failure case; verify editable output and actual consumer behavior. A green MCP connection or version string only establishes transport/tool presence, not art production quality.

## Deliver

Deliver an inventory with unavailable, candidate, source-inspected and runtime-qualified states. No global security changes, automatic purchases or private-source uploads.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A03,M01; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
