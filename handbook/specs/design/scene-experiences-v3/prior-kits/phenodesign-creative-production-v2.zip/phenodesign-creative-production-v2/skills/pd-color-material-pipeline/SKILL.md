---
name: pd-color-material-pipeline
description: Keep color, alpha and material appearance coherent from authoring through final delivery.
license: MIT
---

# Color Material Pipeline

## Author

Record working/display/export color spaces, lighting environment and intended surface. Distinguish color textures from linear data maps. Keep alpha semantics explicit; compare exports against the native source under equivalent illumination. Use approved PhenoDesign tokens, not hardcoded historical swatches as new authority.

## Inspect and iterate

Inspect light/dark backgrounds, gradients, transparent edges and color/contrast at actual sizes. Compare native render, raster poster and web material appearance. Material features unsupported by GLB/web runtime need an explicit bake, approximation or fallback.

## Deliver

Deliver profile/alpha/texture-map metadata and comparative captures. A render that looks correct on one unqualified monitor is not color-accurate certification.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A05,M07; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
