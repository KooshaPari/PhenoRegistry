---
name: pd-illustrator-native
description: Author and revise editable vector art in local Illustrator using its qualified MCP or scripting surface.
license: MIT
---

# Illustrator Native

## Author

Probe the installed app. If approved Illustrator Beta is present, enumerate Adobe’s official MCP actions and instance binding; otherwise use the verified JSX/SDK bridge. Create an owned document with named layers for structural shapes, accents, type and guides. Use minimal control points, coherent joins/radii, optical rather than merely mathematical alignment, and named swatches. Retain live text where editability matters; outline only the delivery copy when permitted.

## Inspect and iterate

Save .ai, reopen it and inspect paths/layers/artboards. Export clean SVG and a raster proof. Compare tiny and large sizes, clipping/masks, stroke expansion and gradients in a browser. Test the wrong-active-document and output-already-exists cases. Use the canary script before a real batch.

## Deliver

Deliver genuine editable .ai plus SVG/PNG derivatives, source observations, token mapping, export settings and consuming paths. Record unsupported MCP actions instead of pretending full Illustrator coverage.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A01,A02,A03,A04; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
