---
name: pd-photoshop-native
description: Create layered raster composites, product imagery, masks and textures with native Photoshop automation.
license: MIT
---

# Photoshop Native

## Author

Qualify UXP/DOM/batchPlay or the installed legacy scripting path. Create an owned document; keep original pixels in a preserved layer or linked/smart source, mask instead of destructively erasing, and separate correction, material, light and output groups. Match perspective, edge softness, light direction and noise. Never use a generative edit to falsify test evidence or invent a product feature.

## Inspect and iterate

Save a layered PSD/PSB, reopen it and inspect named layers/masks/links. Export web variants with explicit profile and alpha. Inspect edges on both light and dark backgrounds, localized patches at 100%, compression at actual delivery dimensions and editable round-trip. Await modal calls and respect cancellation.

## Deliver

Deliver source, layer inventory, input provenance, export variants and real consumer screenshots. A PNG is not the editable source. Native app/UXP execution needs actual host proof.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A05,A06,A07; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
