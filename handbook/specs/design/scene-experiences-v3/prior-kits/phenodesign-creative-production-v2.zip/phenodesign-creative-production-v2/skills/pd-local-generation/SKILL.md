---
name: pd-local-generation
description: Acquire and use local image/3D generation as an optional authoring aid.
license: MIT
---

# Local Generation

## Author

Choose a model/workflow only after estimating disk, RAM/VRAM, licenses and output needs. Preserve model revision/hash, workflow graph, settings, seeds and source rights. Use generated output as raw material; topology, editable structure, unseen geometry and factual accuracy need separate work.

## Inspect and iterate

Compare generation against procedural modeling, direct vector creation and rights-cleared existing assets. Inspect backs/undersides/UVs/materials for 3D, and text/edges/structural errors for raster. Measure actual device behavior and protect concurrent operator workloads.

## Deliver

Deliver reproducible workflow metadata and cleaned editable source. Do not claim a prompt or seed alone guarantees bitwise reproducibility.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
V01,Q01; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
