---
name: pd-raster-compositing
description: Create and optimize raster assets, paintings, cutouts and multi-layer compositions.
license: MIT
---

# Raster Compositing

## Author

Choose subject scale and crop for each target slot before retouching. Preserve a layered master, separate subject/background/masks/grading and record color profile. Match light, perspective and texture frequency. Use local Photoshop or a qualified Krita/GIMP pipeline according to operations needed, not a blanket preference for one tool.

## Inspect and iterate

Check alpha fringing on contrasting backgrounds, unwanted halos, banding and compression. Compare responsive crops; important subjects must not disappear on mobile. Reopen masters and verify linked source files. Explicitly compare a clean vector alternative for simple graphics.

## Deliver

Deliver layered master and named derivative set with dimensions/profile/alpha/bytes. Distinguish sourced photography, generated imagery and factual product imagery.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A05,V03; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
