---
name: pd-typography-layout
description: Create readable, distinctive typography and layout across UI, illustration, video and print.
license: MIT
---

# Typography Layout

## Author

Set information hierarchy, line length, type scale and alignment from the subject and reading task. Use actual product copy. Plan mobile reflow, localization and motion reading time. Treat display type as part of the composition, not a template decoration.

## Inspect and iterate

Inspect at true delivery size, narrow viewports and longer copy lengths. Check overflow, focus order, contrast and font fallback. Record font names/licenses and reference approved installation; do not copy installed font binaries into the repo or ZIP.

## Deliver

Deliver tokens/layout rules, source and responsive proofs. Preserve editable text in masters and do not silently substitute missing fonts.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
Q01,A02; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
