---
name: pd-journey-to-presentation
description: Transform actual journey evidence into annotated media without altering what it proves.
license: MIT
---

# Journey To Presentation

## Author

Use the current recorder and manifest, recording subject commit/build, actions, outcomes, source geometry and timing. Preserve raw captures. Derive annotations as a separate presentation artifact, with source-to-output mapping for time trims/speed and cover/contain/crop/zoom.

## Inspect and iterate

Check annotation rectangles and cursors against actual pixels at different aspect ratios and zoom levels. Failed actions remain failed. Compare source and edited timeline intervals; retain errors and pauses where they matter to the claim.

## Deliver

Deliver immutable master references, derived presentation, transformation metadata and real consuming docs page tests. A polished walkthrough is not a substitute for test assertions.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
R01,R03,R04,R05,Q02; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
