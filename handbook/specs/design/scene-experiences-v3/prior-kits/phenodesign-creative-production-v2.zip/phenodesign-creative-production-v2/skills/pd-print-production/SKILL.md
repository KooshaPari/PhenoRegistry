---
name: pd-print-production
description: Prepare print and packaging assets as a qualified delivery lane.
license: MIT
---

# Print Production

## Author

Obtain physical dimensions, printer requirements, dieline/bleed/trim, profile, finishing and substrate constraints. Author a properly layered Illustrator or qualified layout source with linked assets and font rights. Keep a screen preview separate from the print master.

## Inspect and iterate

Check trim safety, overprint, transparencies, raster resolution at final size and live/output text. Reopen the final source and review printer-agreed exports. Physical proof or printer acceptance is a separate required step when fidelity is critical.

## Deliver

Deliver editable layout, links manifest, printer spec and proof status. The digital canary is not a production-print certification.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
A02; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
