---
name: pd-motion-creative
description: Design motion as staged visual explanation, not scattered transitions.
license: MIT
---

# Motion Creative

## Author

Write the story in beats: establish, reveal, compare, resolve. Define a small timing/easing language and clear focal hierarchy. Develop key poses/style frames before tweening. Use weight, anticipation, overlap and settling only where they support the subject. Protect reading time and avoid simultaneous competing focal points.

## Inspect and iterate

Review without sound, at full speed, in reverse seek and at small mobile size. Compare a reduced-motion cut and a simple still. Check loop seams, transition collisions, narration timing and title-safe regions.

## Deliver

Deliver editable scene/timeline source, storyboard, timed beats, master and distribution exports with sampled-frame reviews.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
M02,M03,M06; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
