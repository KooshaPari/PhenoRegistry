---
name: pd-layered-2-5d
description: Create dimensional design from layered 2D sources without pretending it is a reusable 3D model.
license: MIT
---

# Layered 2 5D

## Author

Break the image or vector into foreground, object, reflection, shadow and background layers. Paint or author hidden margins before moving the camera. Define depth, occlusion and maximum displacement. Choose restrained perspective/parallax or a baked render sequence depending on the slot.

## Inspect and iterate

Inspect extreme angles and scroll endpoints for exposed cutout seams. Test reverse scrolling, resize, coarse pointer, reduced motion and static poster. Keep copy crisp and independent of transformed bitmap planes.

## Deliver

Deliver editable layers/depth/masks, motion recipe, browser behavior and fallback. Compare with an actual 3D route before complex depth reconstruction.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
V01,Q01; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
