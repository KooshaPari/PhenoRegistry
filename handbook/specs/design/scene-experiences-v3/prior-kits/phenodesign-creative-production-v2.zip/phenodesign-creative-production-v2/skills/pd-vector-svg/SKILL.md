---
name: pd-vector-svg
description: Build expressive, clean 2D vector assets that stay editable and work in the frontend.
license: MIT
---

# Vector Svg

## Author

Start from a deliberate shape grammar: angles/radii, stroke weights, fill rules, negative space and alignment. Prefer a small set of named groups to thousands of redundant paths. Use a correct viewBox and intentional preserveAspectRatio. Separate graphical source from semantic DOM controls. Keep reusable icons visually balanced rather than blindly centered in a bounding box.

## Inspect and iterate

Parse and render the SVG. Test clipping, IDs, masks, gradients and pixel alignment across sizes. Sanitize acquired SVG before embedding; reject scripts, foreignObject or external references unless the existing trusted pipeline explicitly handles them. Do not destroy ids needed by animation during optimization.

## Deliver

Deliver editable SVG, optimized runtime SVG, raster proof and browser tests. The included canary exercises named paths and a real SVG/DOM control.

## Load only what is relevant

Use the current PhenoDesign token/source owners. Read `docs/CAPABILITY-MAP.md`
and the applicable native/motion/E2E guide from this package. Primary sources:
V01,V02; resolve them in `resources/SOURCES.md`. Also load relevant v1 3D skills
for meshes, materials, lighting, GLB, realtime scenes or scroll stories.
