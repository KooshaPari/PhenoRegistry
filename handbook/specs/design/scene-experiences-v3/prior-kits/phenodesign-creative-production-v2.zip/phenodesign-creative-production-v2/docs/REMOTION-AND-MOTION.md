# Remotion and the rest of the motion stack

Remotion is a first-class **authoring, preview, rendering and embedding**
adapter, not only a video converter. Extend the imported `remotion/doc-embeds`
package; keep its genuine journey consumer and add reusable creative scenes.

## Full lifecycle

Brief/storyboard → source-backed scene assets → typed props and runtime
validation → frame-driven composition → Studio/Player review → sampled
frames and audio/caption checks → local renderer → full decode/metadata
checks → responsive poster/video/doc embed → consuming-page journey.

Keep Remotion, renderer, CLI, Player and optional packages at mutually
compatible exact versions in the actual lockfile. Do not blindly overwrite
React/Vue versions or existing workspace rules. Resolve browser binaries
explicitly; record path+version and rendering backend. Installation or a
successful Studio launch does not certify render workers.

Animations should depend on frame/input values, not Date.now(), uncontrolled
requestAnimationFrame or unseeded randomness. Any GSAP integration must seek
its timeline explicitly; an ordinary live-scroll animation is not inherently
deterministic when rendered into video. Three scenes require fixed animation
stepping, stable asset readiness and actual graphics-backend qualification.

`examples/remotion/` provides a small SVG-based Composition using the same
normalized progress idea as the vector canary. It is original source, not a
claim of a rendered Remotion sample. No Remotion package was installable in
the preparation environment. `integration/overlay/remotion/doc-embeds/bin/`
contains the local-only safe runner; it uses installed dependencies and
isolated staging and does not silently call a package installer.

## Other adapters

Use Motion Canvas for code-driven explanatory animation when its authoring
model fits; Manim for mathematical/structural explanation; Rive for stateful
vector experiences; Lottie for compatible exported vector timelines; AE for
licensed composition workflows when installed/qualified; FFmpeg for decode,
transcode, mux, image-sequence assembly and objective media checks. These are
alternatives or composable adapters, not dependencies to add to every site.

Rive runtime loading/scripting is not proof of autonomous .riv authoring.
A community rive-cli authoring project surfaced during research but could
not be fully inspected; it remains a **candidate**, not a bundled verified
backend. Test .riv source reopening and runtime state parity before adoption.
Similarly, verify Lottie feature support in the exact target renderer; never
promise all After Effects effects survive export.

## Licensing and privacy

The imported doc-embeds package's license field does not license the Remotion
runtime itself. Check the current Remotion license against actual use/team.
Official agent skills are acquired directly from the upstream using the
recorded workflow in `resources/UPSTREAM-ACQUISITION.md`; they are not copied
into this package under an invented permissive license. Hosted rendering,
voice/music, stock and generative tools have separate rights and data flows.

References M01–M08 and supplemental catalog entries.

## Guarded runner scope

The included runner uses bounded canary policies: integer frame rates, even H.264
output dimensions, local media, and limited duration/payload/concurrency. These
are not universal restrictions on creative production or Remotion. Extend the
policy deliberately for rational broadcast timebases and larger licensed jobs.
GIF mode retains an MP4 intermediate for review. Input directories and repository
writes require an external worker lease; path checks are not an OS sandbox.
POSIX owned-child timeout/escalation is tested; Windows descendant cleanup still
requires qualification through a native Job Object broker. Actual Remotion CLI
rendering, browser flags on the installed version and crop/zoom component wiring
remain on-device integration gates, even though the pure helpers pass tests.
