# Finish the imported composition geometry fix

The pure `fit-transform.mjs` helper is tested, but wiring the existing React
components must be validated in the installed Remotion package. Do not mark
that runtime fixed just because the geometry unit tests pass.

1. Extend the existing Scene schema (version/provenance retained) with actual
   `sourceWidth`, `sourceHeight`, `fit` and an explicit local scene duration.
   The safe runner probes source geometry and rejects mismatching declared
   dimensions. The recorder/converter must retain it too.
2. In DocEmbed, pass output width/height separately from each scene's source
   width/height. Pass `sceneFrames(scene, fps)` as local duration.
3. Replace separate scaleX/scaleY cover-fit logic. Compute uniform scale and
   offsets with the helper, including zoom around the same anchor as the
   media. Either transform the media and highlight/cursor group together in
   source coordinates, or map coordinates through the same matrix.
4. Keep caption/callout UI outside the transformed source group unless the
   callout is explicitly attached to a source feature. Clip the media region;
   avoid hiding text under the caption bar.
5. Still zoom progress uses frame/max(1,sceneFrames-1), not composition duration.
6. Add real rendered tests for 1600×900 source → 800×800 cover, contain, 2× zoom,
   a very short scene, multiple scenes and source metadata mismatch. Validate
   pixel locations, not just React props. Compare actual cropped imagery.

The existing component's property names are not assumed to accept a new
matrix until inspected. Preserve Highlight/Callout timing semantics. Use
staging isolation and geometry tests together, but retain separate statuses.
