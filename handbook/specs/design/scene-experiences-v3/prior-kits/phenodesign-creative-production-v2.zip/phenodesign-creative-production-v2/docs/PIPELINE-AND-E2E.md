# The end-to-end production contract

## Shared pipeline

Brief → placement and audience → reference analysis → medium/tool decision
→ exact tool/rights probe → editable source → structural preflight → preview
→ semantic and visual critique → revision → export/optimization → real
consumer integration → interaction/accessibility/performance checks →
media decode/reopen → immutable evidence receipt → approved publication.

Do not force a single universal format to pretend to preserve Illustrator,
Photoshop, Blender and code-based source equally. Reference native masters
and their derivatives. Add a versioned creative extension to the *current*
asset/journey manifest at integration time; `contracts/` is a candidate
boundary specification, not a new canonical registry.

## Common source fields

Source repo+commit/dirty patch; brief id; source document hashes; generator
script/workflow hash; tool, plugin and renderer versions; asset/model licenses;
input references; color profile and alpha mode; units and geometry metadata;
seed where meaningful; ordered exports; resource budget; semantic assertions;
actual consumer paths; reviewer identity; result state and exact failures.
Do not copy font binaries. Record installed font family/version and rights.

## Tests by stage

| Stage | Positive case | Negative case that must fail |
|---|---|---|
| Native authoring | named editable layers/objects; source saved and reopened | flattened raster renamed .ai/.psd; unsaved source; missing layer |
| Input custody | all inputs approved, hashed and inside allowed roots | path traversal, symlink escape, missing provenance |
| Vector | valid bounded viewBox and expected named paths | clipped art, external references, injected SVG script |
| Raster | actual dimensions, expected nonblank pixels and alpha | wrong profile, broken premultiplication, empty output |
| 3D | semantic part names, bounds, textures, animations | missing back faces, scale/pivot errors, unrealized export material |
| Timeline | frame 0/middle/end, reverse seek and boundary frames | wall-clock timers, unseeded randomness, scene-overrun |
| Interactive | actual DOM/canvas action changes observed state/pixels | event fired but no outcome; inaccessible control; detached object |
| Scroll | reverse, fast jumps, resize, restored scroll position | one-way timeline, trapped scrolling, layout jump |
| Media | decode every frame; expected fps/duration/size/audio | zero-byte file, corrupt trailing frames, silent narration, bad sync |
| Accessibility | visible focus, keyboard/touch alternatives, reduced motion | mandatory drag, canvas-only meaning, animation despite opt-out |
| Performance | bounded transfer, CPU/GPU memory, frame timings on named device | software-rendered test labeled hardware-GPU success |
| Concurrency | independent staging, leases, filenames and cleanup | one worker deletes another's source/staging or uses operator window |
| Evidence | raw master+transform provenance+assertions+version | polished video incorrectly presented as untouched proof |

## Runtime observation, not just screenshots

Record chosen renderer, WebGL/WebGPU support, actual GL vendor/renderer where
available, DPR, viewport, OS/browser version, GPU/driver, codec versions,
resource peaks, console/network errors, and source/consumer revisions.
Readiness should be a semantic marker or asset-loaded condition; do not rely
on an arbitrary sleep or universal network-idle on streaming/live pages.

A model's own review is useful but not independent proof. Pixel checks must
use actual captured pixels. Structural assertions cannot alone verify art
quality; a screenshot cannot alone verify intent, transitions or licensing.
Use an independent verifier/human for publication-critical quality and keep
rejected iterations, with no fake render or generated screenshot evidence.

## Stateful versus time-based output

Use normalized narrative progress p ∈ [0,1] only for authored story beats.
For frame media use p = frame/max(1,frames-1). For interactive scenes, input
state and p are separate; scrolling must not overwrite a user's explicit
control state unless specified. Physics simulations need fixed stepping or
baked caches for video export. Rive/Lottie/Three adapters must be compared at
multiple sampled states against their source renderer.

## Evidence and presentation are two different pipelines

Raw test capture stays immutable. Edited docs/social/demo media are derived
presentation artifacts with their own title, crops, speed changes, overlays,
narration and timeline mapping. A feature that failed in the source journey
cannot be “fixed” by compositing a successful UI into the recording.

## Resource admission

Default proposal: one expensive native/GPU job at a time on the operator's
machine until measured otherwise; low-priority CPU transforms can share a
separate budget. Probe actual hardware, not planned RAM/GPU upgrades. Bound
CPU threads, RAM/VRAM, output bytes, open app sessions and render time. Honor
cancellation and clean only the owning job's resources. No background work
on the user's device is started by this downloadable package.
