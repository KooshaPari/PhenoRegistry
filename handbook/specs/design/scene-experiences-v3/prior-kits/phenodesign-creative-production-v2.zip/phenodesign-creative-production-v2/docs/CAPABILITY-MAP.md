# Capability map: broad by design, qualified per adapter

“All forms” means an extensible coverage model, not a claim that every backend
is already installed or production verified. Select by placement and purpose.

| Family | Authoring / tool route | Preserve | Deliver | Required proof |
|---|---|---|---|---|
| Identity, layout, type | Illustrator, CSS, Penpot/Figma where justified | Editable .ai / design project / tokens | SVG, CSS, raster derivatives | Legibility at real sizes; live text, token inheritance, localization |
| Vector illustration and icons | Illustrator scripting/MCP; SVG; Inkscape | Named paths/layers and .ai/.svg | SVG, sprite, PNG, print derivative | viewBox, clipping, path complexity, contrast, focus/accessibility |
| Raster art, paint, compositing | Photoshop UXP/JSX; Krita; GIMP | Layered .psd/.kra/.xcf plus masks | PNG/WebP/AVIF/JPEG/EXR as appropriate | Layer preservation, alpha edges, missing links, profile, reopen |
| Photo treatment and product imagery | Photoshop and rights-cleared photo inputs | Non-destructive source + masks/adjustments | Responsive image set and poster | No invented product features; consistent light; device display checks |
| 2D procedural and generative art | SVG/Canvas; local node-graph/model tools | Seeded recipe/workflow and source assets | Vector/raster plus video loops | Reproducibility limits; provenance; licensing; iteration metrics |
| 2D interactive vector | DOM/SVG, Rive; qualified authoring adapter | State machine + .riv or SVG source | Web/native runtime asset | All states/transitions, keyboard parity, reset, reduced motion |
| 2D canvas/sprites/particles | PixiJS/Canvas; sprite authoring tools | Atlas sources, pivots, timings, code | Atlas+metadata, runtime bundle | Hit areas, DPR, resize, hidden-tab pause, fill-rate |
| 2.5D | CSS perspective, layered SVG, image+depth | Layers, depth, masks, camera recipe | HTML, composited sequence, video | No uncovered layer edges; occlusion, touch and reduced motion |
| 3D procedural/hard-surface | Blender Python/Geometry Nodes | Editable .blend, parameter recipe | GLB, renders, optional USD | Silhouette, normals, scale/pivots, UVs, texture/export parity |
| 3D sculpt/organic/character | Blender; qualified specialist tools | Sculpt/high+low meshes, rigs | Optimized animated asset, image/video | Retopo, deformation, silhouette, skin/material checks |
| 3D scans / image-to-3D | Qualified local photogrammetry/generation | Inputs+rights, model/workflow, cleaned mesh | Retopologized GLB and render masters | Reject invented geometry, baked light, bad backs/undersides |
| Materials, textures, light | Blender; Photoshop/Krita; optional Substance | Node graphs, layers, bakes, HDRI provenance | PBR texture set, light rigs, render masters | Color vs data maps, roughness, seams, metallic/transmission fallback |
| Rigging, animation and simulation | Blender and approved engine tooling | Rig/action/constraint/cache source | GLB clips, baked sequences, video | Deterministic seek, bake equivalence, loop seams, bounds |
| CAD / precise product visualization | Approved CAD tool + Blender import | CAD source, tolerances, tessellation recipe | Visualization mesh, STEP/STL only where requested | Unit conversion; visualization not manufacturing certification |
| Realtime 3D and shaders | Three.js/R3F or existing engine | GLB + scene + shader + controls | Responsive web/desktop/native surface | GPU path vs fallback, budgets, context loss, picking and occlusion |
| Scroll-driven and active props | Native scroll + GSAP/Motion when useful | Story beats + reversible timeline | Real consuming product page | Reverse/fast scroll, resize, focus, touch, no scroll trapping |
| Motion graphics / explainers | Remotion; Motion Canvas; AE when qualified | Composition code/.aep + timed scene spec | MP4/WebM/masters/posters | Frame-based timing, seek determinism, aspect variants, safe text |
| Recorded journeys and tutorials | Existing journey capture + Remotion/FFmpeg | Immutable capture master + transformations | Annotated embed, captions/transcript | Action/state/pixel proof, correct crop/timing, no fabricated evidence |
| Video editing/compositing | Remotion/FFmpeg; AE/Resolve when warranted | EDL/timeline/source projects | Master+distribution codecs | Decode, duration/fps, audio sync, alpha, subtitles, poster and playback |
| Diagrams / data visualization | SVG, Graphviz/Mermaid, D3, Manim | Data/schema/graph and layout source | Semantic HTML/SVG, animated explanation | Data truth, labels, navigation, non-color encoding, source trace |
| Print / packaging / large format | Illustrator, qualified page-layout tool | Editable layout, linked sources, profile spec | Printer-agreed export | Bleed/trim/overprint/CMYK/font-rights; actual print proof |
| Audio-reactive / captions | FFmpeg, approved synthesis/transcription, DAW export | Tracks/stems/caption timing+rights | Audio track, timed text, visual mapping | No operator audio interception; sync, silence, captions, licensing |
| AR/XR and spatial | Only qualified target engine/runtime | Spatial scene+interactions+device settings | Target-specific build | Real device test; unsupported device remains blocked |

## Do not force one tool onto every medium

Illustrator is not a mesh editor. A Photoshop generative layer is not a clean
3D model. A .riv runtime player is not an authoring tool. A Remotion Player is
not an arbitrary realtime simulation engine. A screenshot is not a layered
master. A `.blend` that has never reopened is not a proven reusable source.

Every row is selectable through the same PhenoDesign surface. Workers may be
native applications, headless CLIs, browser runtimes or approved remote
services, but their status, costs, sources and evidence remain explicit.
