# Source-aware audit · September 15, 2026

This is a focused read of the named paths, not a full repository certification.
Source metadata is in `resources/repo-snapshot.json`. Fetch current revisions
before applying findings; preserve valid concurrent work.

## Observed migration

GitHub PR #87 was open (`merged=false`), base
`d11733b1525cb97e045dc7f8d67a05df5501f6c1`, head
`6c99a15337505b55f46a9f576465db5e4053b416`. It adds
`packages/journey-viewer`, `packages/playwright-record`,
`packages/journey-playwright`, `remotion/doc-embeds`, `remotion/borrowed`,
and provenance; its description assigns Rust CLI code to phenotype-tooling
PR #358. That description is not proof #358 merged or passed conformance.

The root package remains `@phenotype/design` 2.0.1, a token/theme package;
its workspaces pattern is `packages/*`, not `remotion/*`. Imported Remotion
is therefore not automatically included by that workspace glob. The README
says archived although repository metadata says `archived=false` and an
active migration PR exists. Reconcile README, package scripts and ownership;
do not treat a stale text banner as the user's current product decision.
The description points to asset-engine. Its `main/README.md` fetch returned
404 in this session; this does **not** establish that the repo was deleted.

## Findings on the imported Remotion path

| ID | Exact observation | Consequence and action |
|---|---|---|
| PD-R01 | `bin/render.mjs` deletes shared `public/` and uses shared `.staged-props.json`. | Parallel invocations can delete/overwrite one another. Use per-job owned staging. |
| PD-R02 | `stage()` uses only `basename(srcAbs)`. | `a/frame.png` and `b/frame.png` collide. Address staged inputs by content hash and retain mappings. |
| PD-R03 | Arbitrary absolute paths are accepted; input roots are not constrained. | A manifest can include unintended local files. Realpath-check every input beneath an approved asset root; bound size and media types. |
| PD-R04 | `spawnSync('npx', args, {shell:true})`; props/id flow into arguments. | Avoid shell interpretation and floating package download. Run installed CLI via Node with an argument vector and validated id. |
| PD-R05 | Only TypeScript interfaces describe EmbedSpec; renderer JSON is unchecked. | Add runtime validation for dimensions, timing, sources, format, annotation coordinates and duration. |
| PD-R06 | SceneView claims cover-fit but computes independent width/height ratios. | Cover cropping needs a uniform scale and offsets, not separate stretch ratios. Zoom must transform evidence overlays with media. |
| PD-R07 | DocEmbed supplies output dimensions as source dimensions. | Actual recorded screenshot/video sizes are lost. Carry per-scene source geometry and display fit. |
| PD-R08 | Still zoom uses composition duration via useVideoConfig. | A shorter scene may not reach its intended final zoom. Use local scene duration and a defined last-frame convention. |
| PD-R09 | package uses broad `^4.0.0` ranges, and repository metadata still names phenotype-journeys. | Align exact compatible dependencies in current lockfile and update provenance without erasing origin. |

These are source-level findings, not reproduced native-app defects. The pack
includes a replacement staging/runner and independently tested fit-transform
module. Composition wiring is explicitly left as a reviewed integration task
because its React/Remotion runtime was not installed in this environment.

## Existing authorities to preserve

PhenoDesign owns coherent creative direction, tokens, recipes, reusable visual
components, authoring surface, media representations and review UI. Keep
production evidence generation/verifier ownership where the current migration
places it. Tracera remains the persistent product model; AgilePlus owns scoped
execution. Do not create a new registry, renderer farm, task scheduler or
asset ledger just to ship a first vertical slice.

Read source references R01–R06 in `resources/SOURCES.md`.
