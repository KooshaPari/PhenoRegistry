# Adobe on-device authoring

## Preferred routes

**Illustrator:** Adobe's official April 28, 2026 documentation describes a
built-in MCP server in **Illustrator Beta**, with same-device Codex/Claude
Code/Cursor connection and a server URL/authentication key exposed by the app.
Probe the actual installation and tool list. Do not assume stable Illustrator
has that server. Do not embed copied authentication keys in this ZIP, git,
logs, screenshots or skill text. Use its supported actions where suitable;
keep deterministic JSX/scripts and SDK routes for functions not exposed.

**Photoshop:** UXP scripts/plugins, Photoshop DOM and batchPlay are the core
programmable route. `executeAsModal` serializes app mutations for UXP API v2;
await it, preserve cancellation and protect owned documents. UXP filesystem
permissions/tokens differ from Node.js. A `.uxpscript` runs inside Photoshop,
not through `node`. Adobe's “headless script” wording does not establish a
standalone Linux-hosted desktop Photoshop server.

The included `.jsx` files are **legacy-script canaries**, not a recommendation
to discard a working UXP implementation. They create simple genuinely layered
native files, export PNG/SVG where appropriate, reopen the saved master and
check layers. They require host execution and are not verified here. A UXP
probe is included to report the host and API availability without changing
documents. Advance either path only with an actual native receipt.

## Bootstrap once, operate repeatedly

1. Reserve an authorized isolated app instance/session. Keep the operator's
   ordinary documents and display out of the work area.
2. Resolve app version, tool list, license, plugin support and an allowed job
   root. Select the approved native invocation mechanism (existing journey
   worker, official MCP, script runner, or verified SDK bridge).
3. Run the canary in an empty job directory. Pass its path via the documented
   environment hook; a generated wrapper may set the same variable in a
   reviewed native script if the already-running app does not inherit it.
4. Reopen the actual .ai/.psd, inspect named layers/paths, capture native view,
   export again and compare the derivative. Test deliberate missing input,
   existing output, cancellation and a wrong active document.
5. Keep the native adapter serial until instance binding, cleanup and output
   isolation pass. Concurrency is a worker property, not agent chat count.

## Fail honestly

APP_MISSING, HOST_UNREACHABLE, ENTITLEMENT_REQUIRED, SCRIPT_API_UNSUPPORTED,
MCP_PERMISSION_REQUIRED, FONT_MISSING and SESSION_BUSY are useful blockers.
Do not relabel an Inkscape result as Illustrator, or a PNG as a Photoshop
source. Do not automatically change OS security/remote-login settings, replace
stable apps with betas, purchase licenses, or upload private art to Firefly.

References A01–A07. Native scripts are in `adapters/adobe/`.
