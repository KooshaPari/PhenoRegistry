# Primary resources and scoped observations

The original 36-resource catalog remains in `frontend-3d-v1/resources/`.
The entries below supplement it. Inspection is not native/runtime certification.

## R01 · PhenoDesign partial migration PR #87

https://github.com/KooshaPari/PhenoDesign/pull/87

Role: repo migration. Status: connector-inspected. Open and unmerged in observed snapshot; do not infer Rust migration acceptance.

## R02 · PhenoDesign package manifest

https://github.com/KooshaPari/PhenoDesign/blob/d11733b1525cb97e045dc7f8d67a05df5501f6c1/package.json

Role: workspace integration. Status: connector-inspected. Root tokens/theme export contract must be preserved.

## R03 · Imported doc-embeds renderer

https://github.com/KooshaPari/PhenoDesign/blob/6c99a15337505b55f46a9f576465db5e4053b416/remotion/doc-embeds/bin/render.mjs

Role: renderer audit. Status: connector-inspected. Observed shared staging, basename collisions and shell invocation.

## R04 · Imported SceneView

https://github.com/KooshaPari/PhenoDesign/blob/6c99a15337505b55f46a9f576465db5e4053b416/remotion/doc-embeds/src/components/SceneView.tsx

Role: source geometry. Status: connector-inspected. Cover crop and zoom mapping require correction.

## R05 · Imported DocEmbed

https://github.com/KooshaPari/PhenoDesign/blob/6c99a15337505b55f46a9f576465db5e4053b416/remotion/doc-embeds/src/DocEmbed.tsx

Role: scene composition. Status: connector-inspected. Output dimensions reused as source dimensions.

## R06 · PhenoDesign README

https://github.com/KooshaPari/PhenoDesign/blob/d11733b1525cb97e045dc7f8d67a05df5501f6c1/README.md

Role: stale authority. Status: connector-inspected. Archived text conflicts with active repository metadata; reconcile.

## A01 · Adobe Illustrator developer platform

https://developer.adobe.com/illustrator/

Role: native vector authoring. Status: web-inspected. JS/AppleScript/VBScript, panels and SDK are distinct surfaces.

## A02 · Adobe Illustrator script installation and execution

https://helpx.adobe.com/illustrator/desktop/automate-visualize-data/automate-actions/install-and-run-scripts.html

Role: native scripting. Status: web-inspected. Probe actual host and supported script route.

## A03 · Adobe Illustrator Beta MCP connection

https://helpx.adobe.com/in/illustrator/desktop/connect-with-other-apps-and-tools/connect-illustrator-to-ai-tools.html

Role: official local MCP. Status: web-inspected. Beta app; same device; endpoint and key from installed app.

## A04 · Adobe Illustrator Beta supported AI-tool actions

https://helpx.adobe.com/in/illustrator/desktop/connect-with-other-apps-and-tools/work-with-illustrator-documents-from-ai-tools.html

Role: native MCP scope. Status: web-inspected. Supported action list and active-document workflow are bounded.

## A05 · Photoshop scripting

https://helpx.adobe.com/photoshop/using/scripting.html

Role: native raster authoring. Status: web-inspected. Actual licensed Photoshop host is required.

## A06 · Photoshop UXP executeAsModal

https://developer.adobe.com/photoshop/uxp/2022/ps-reference/media/executeasmodal

Role: modal mutation isolation. Status: web-inspected. Await mutations and preserve cancellation; not a general worker lease.

## A07 · Photoshop UXP scripting

https://developer.adobe.com/photoshop/uxp/2022/scripting/

Role: UXP scripts vs plugins. Status: web-inspected. Host-executed scripts, APIs and permissions differ from Node.

## A08 · Adobe creativity connector

https://developer.adobe.com/adobe-for-creativity/

Role: optional service discovery. Status: web-inspected. Separate connector/service; not proof of local app access or entitlement.

## M01 · Official Remotion agent skills

https://www.remotion.dev/docs/ai/skills

Role: upstream skill acquisition. Status: web-inspected. Official npx skills acquisition; inspect/pin source and current rights before redistribution.

## M02 · Remotion frame-driven properties

https://www.remotion.dev/docs/animating-properties

Role: motion authoring. Status: web-inspected. Use frame-dependent deterministic state.

## M03 · Remotion render CLI

https://www.remotion.dev/docs/cli/render

Role: render automation. Status: web-inspected. Use installed local CLI, file props, isolated public dir and explicit browser.

## M04 · Remotion renderMedia API

https://www.remotion.dev/docs/renderer/render-media

Role: render orchestration. Status: web-inspected. Existing runner integration alternative; validate version-specific options.

## M05 · Remotion ThreeCanvas

https://www.remotion.dev/docs/three-canvas

Role: 3D video composition. Status: web-inspected. ThreeCanvas requires separate graphics runtime qualification.

## M06 · Remotion license and terms

https://www.remotion.dev/docs/license

Role: licensing. Status: web-inspected. Do not infer runtime rights from a consumer package license.

## M07 · FFmpeg ffprobe documentation

https://ffmpeg.org/ffprobe.html

Role: media validation. Status: web-inspected. Probe streams plus full decode and content checks; metadata alone is insufficient.

## M08 · Remotion official skills repository

https://github.com/remotion-dev/skills

Role: upstream skill source. Status: connector-inspected. Metadata exposed no recognized license; package links/acquisition instructions, not copied skill source.

## V01 · Inkscape command-line usage

https://wiki.inkscape.org/wiki/Using_the_Command_Line

Role: headless vector export. Status: web-inspected. Actual CLI canary ran here; not equivalent to Adobe source authoring.

## V02 · Lottie documentation

https://lottiefiles.github.io/lottie-docs/

Role: vector timeline format. Status: web-inspected. Validate exact target renderer and export feature parity.

## V03 · Photoshop UXP API documentation

https://developer.adobe.com/photoshop/uxp/

Role: raster automation. Status: reference-entry. Use matching host API documentation, not guessed batchPlay descriptors.

## V04 · Rive runtimes

https://rive.app/

Role: interactive vector candidate. Status: web-inspected. Runtime playback does not certify authoring; qualify .riv creation separately.

## V05 · PixiJS introduction

https://pixijs.com/8.x/guides/getting-started/intro

Role: 2D canvas/WebGL rendering. Status: web-inspected. Runtime resource and interaction testing required.

## V06 · Motion Canvas docs

https://motioncanvas.io/docs/

Role: code-driven motion graphics. Status: web-inspected. Alternative authoring model, not mandatory with Remotion.

## V07 · Manim Community docs

https://docs.manim.community/en/stable/

Role: mathematical/structural animation. Status: web-inspected. Pin actual installed release; validate exports.

## V08 · Penpot plugin documentation

https://help.penpot.app/plugins/

Role: optional design-source tooling. Status: web-inspected. A candidate when source collaboration or tooling justifies it.

## V09 · Community rive-cli

https://george-rd.github.io/rive-cli/

Role: candidate autonomous .riv authoring. Status: search-surfaced-open-failed. Not Adobe/Rive official and not runtime-qualified or bundled.

## Q01 · W3C interaction animation guidance

https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html

Role: motion accessibility. Status: web-inspected. Respect motion preference and retain functionality; full conformance needs more tests.

## Q02 · Playwright Page API

https://playwright.dev/docs/api/class-page

Role: browser verification. Status: web-inspected. Use semantic readiness, actual assertions and renderer-aware screenshots.
