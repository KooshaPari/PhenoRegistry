# Validation and boundaries • 15 September 2026

## Executed in this preparation environment

| Layer | Actual result | Evidence |
|---|---|---|
| Node utilities | **37 tests passed**, 0 skipped: staging/schema/path limits, collision/concurrency, fit/zoom/frame math, owned-child error/timeout/escalation | `node-tests.tap` |
| Target overlay test layout | The same **37 tests** passed from the overlay's actual relative import layout. This is a repeat, not 37 additional independent tests. | `overlay-node-tests.tap` |
| Python | **26 tests passed**: deterministic vector source; extension schema; guarded installer/preflight/conflict/rollback; skill discovery and conflict checks | `python-tests.txt` |
| Actual SVG consumer | **18 checks passed**: captured pixels, layer movement, keyboard, animation advancement, pause stability, reset, reduced motion, mobile overflow, no-JavaScript state, browser errors | `browser-inline-final/` |
| Offline resource index | **4 checks passed**, including search and mobile layout | `index-final/` |
| Vector-to-media pipeline | Editable SVG; independent Inkscape PNG; 48 CairoSVG frames; a 640×480, 24 fps, 2-second H.264 video; ffprobe dimensions/count/duration; full FFmpeg decode | `vector-pipeline/` |
| Static source parsing | New Python AST, Node modules, Adobe canary JavaScript after stripping native #target lines, UXP script and JSON parsed. This is not host execution. | `syntax-checks.json` |
| Original v1 preservation | **84 files compared byte-for-byte** with the provided original ZIP; all identical | `v1-preservation.json` |

Reproduction commands from the pack root:

```sh
node --test tests/*.test.mjs
node --test integration/overlay/remotion/doc-embeds/tests/creative-*.test.mjs
python -m unittest discover -s tests -p 'test_*.py' -v
python scripts/build_vector_canary.py --out /new/vector-run
python scripts/browser_canary.py --transport inline --out /new/browser-run
python scripts/check_index.py --out /new/index-run
python scripts/verify_package.py
```

Use `--transport http` for browser canaries on the qualified local worker. The
browser here rejected HTTP localhost and file navigation with
`ERR_BLOCKED_BY_ADMINISTRATOR`. We did **not** disable that policy. Explicit inline
fixture mode loads the actual self-contained HTML with Playwright `set_content`.
It tests real SVG/DOM rendering and interactions, but **not** HTTP routing,
deployment, the live PhenoDesign site, network loading, WebGL or the user's device.
The blocked HTTP attempt remains in `browser-http-blocked.txt`.

The first inline attempt also caught a test synchronization failure: an immediate
assertion ran before the reduced-motion event was handled. The final test waits
for the actual disabled control. That earlier observation is retained in
`browser-inline/`. Separately, the actual demo's fractional animation accumulator
was fixed: updating an integer-step range directly each frame could round away
motion. The passing test now checks that the position really advances.

## Not executed; do not count these as passed

Native Illustrator/Photoshop automation, Adobe source reopening, official Beta MCP
connection, Blender, true GPU/WebGL production rendering, full Remotion dependency
runtime, the real imported React composition, Windows descendant-process cleanup,
real VitePress consumption, cloud publishing, AR/XR, print proofs, external media
rights, and performance under the user's gaming/DAW workload were not qualified.
The code and handoff describe how to run those gates on the approved device.

The React crop/zoom/source-coordinate integration is specifically still pending
in `docs/COMPOSITION-WIRING.md`. The included matrix math is tested; the existing
components have not been wired or rendered here. The safe renderer is original
replacement code, with pure helpers tested—not a certified full Remotion render.

## Provenance

The repo was inspected through authenticated GitHub connector reads at the
recorded snapshot. No commit, branch creation, merge, push or live repo modification
was made. Container DNS prevented fetching dependencies/source over the network;
no dependency download success is claimed. The installer tests use temporary local
fixtures and the overlay tests use provided source, not a checked-out full repo.

The prior v1 kit and its evidence are inherited unchanged, not re-executed. Content
hashes establish byte consistency, not trusted producer identity, genuine device
execution, license entitlement or subjective design quality. Production evidence
must come from the existing trusted worker/verifier boundary.
